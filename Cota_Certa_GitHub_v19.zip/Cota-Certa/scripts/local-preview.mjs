import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import worker from "../dist/server/index.js";

const staticFiles = {
  "/": ["dist/index.html", "text/html; charset=utf-8"],
  "/index.html": ["dist/index.html", "text/html; charset=utf-8"],
  "/styles.css": ["dist/styles.css", "text/css; charset=utf-8"],
  "/app.js": ["dist/app.js", "text/javascript; charset=utf-8"],
  "/import.js": ["dist/import.js", "text/javascript; charset=utf-8"],
  "/vendor/pdf.mjs": ["dist/vendor/pdf.mjs", "text/javascript; charset=utf-8"],
  "/vendor/pdf.worker.mjs": ["dist/vendor/pdf.worker.mjs", "text/javascript; charset=utf-8"],
  "/vendor/jszip.min.js": ["dist/vendor/jszip.min.js", "text/javascript; charset=utf-8"]
};
const port = Number(process.env.COTA_CERTA_PORT || 5500);

createServer(async (req, res) => {
  try {
    const path = new URL(req.url, `http://localhost:${port}`).pathname;
    if (staticFiles[path]) {
      const [file, type] = staticFiles[path];
      res.writeHead(200, { "Content-Type": type, "Cache-Control": "no-store" });
      return res.end(await readFile(new URL(`../${file}`, import.meta.url)));
    }
    if (!path.startsWith("/api/")) { res.writeHead(404); return res.end("Não encontrado"); }
    const chunks = [];
    let size = 0;
    for await (const chunk of req) { size += chunk.length; if (size > 8192) { res.writeHead(413); return res.end("Solicitação muito grande"); } chunks.push(chunk); }
    const request = new Request(`http://localhost:${port}${req.url}`, { method:req.method, headers:req.headers, body:["GET","HEAD"].includes(req.method) ? undefined : Buffer.concat(chunks) });
    const response = await worker.fetch(request, {});
    res.writeHead(response.status, Object.fromEntries(response.headers));
    res.end(Buffer.from(await response.arrayBuffer()));
  } catch { res.writeHead(500); res.end("Falha na consulta"); }
}).listen(port, "127.0.0.1", () => console.log(`Cota Certa: http://127.0.0.1:${port}`));
