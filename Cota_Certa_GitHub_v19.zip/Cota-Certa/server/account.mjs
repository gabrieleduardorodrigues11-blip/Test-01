const accountJson = (body,status=200) => Response.json(body,{status,headers:{"Cache-Control":"no-store"}});
const normalizeEmail = (value) => String(value || "").trim().toLowerCase();
const toHex = (bytes) => [...bytes].map((b)=>b.toString(16).padStart(2,"0")).join("");
const hexBytes = (value) => Uint8Array.from(value.match(/.{2}/g) || [],(hex)=>parseInt(hex,16));
const accountProfile = (row,env) => ({id:row.id,email:row.email,name:row.name,role:normalizeEmail(env.COTA_BASE_OWNER_EMAIL)===row.email?"Administrador":"Cotador"});

async function passwordDigest(password,salt) {
  const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(password),"PBKDF2",false,["deriveBits"]);
  // Cloudflare Workers limits PBKDF2 to 100,000 iterations per call.
  const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt:hexBytes(salt),iterations:100000,hash:"SHA-256"},key,256);
  return toHex(new Uint8Array(bits));
}
async function legacyDigest(email,password) {
  return toHex(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(`cota-certa:${email}:${password}`))));
}
function equalHex(a,b) {
  if(a.length!==b.length)return false;
  let diff=0; for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);
  return diff===0;
}

export async function handleAccount(request,env) {
  const userId=request.headers.get("oai-authenticated-user-id");
  const verifiedEmail=normalizeEmail(request.headers.get("oai-authenticated-user-email"));
  if(!userId || !/^[a-zA-Z0-9_-]{8,128}$/.test(userId) || !/^\S+@\S+\.\S+$/.test(verifiedEmail))
    return accountJson({error:"Entre com a conta ChatGPT vinculada ao seu e-mail para continuar.",signInRequired:true},401);
  if(!env.DB)return accountJson({error:"O acesso está indisponível no momento. Tente novamente."},503);
  try {
    const existing=await env.DB.prepare("SELECT id,email,name,password_salt,password_hash,created_at FROM accounts WHERE id=?").bind(userId).first();
    if(request.method==="GET")return accountJson({email:verifiedEmail,registered:Boolean(existing),profile:existing?accountProfile({...existing,email:verifiedEmail},env):null});
    if(request.method!=="POST")return accountJson({error:"Método não permitido."},405);
    if(request.headers.get("content-type")?.split(";")[0]!=="application/json")return accountJson({error:"Solicitação inválida."},415);
    if(Number(request.headers.get("content-length"))>4096)return accountJson({error:"Solicitação muito grande."},413);
    const raw=await request.text();
    if(raw.length>4096)return accountJson({error:"Solicitação muito grande."},413);
    const input=JSON.parse(raw);
    const email=normalizeEmail(input.email);
    const action=input.action;
    const password=String(input.password || "");
    if(email!==verifiedEmail)return accountJson({error:"Use o e-mail da conta ChatGPT com que você entrou."},403);
    if(!["login","signup","recover"].includes(action))return accountJson({error:"Ação inválida."},400);
    if(password.length>256 || password.length<(action==="login"?6:8))return accountJson({error:"A senha deve ter pelo menos 8 caracteres."},400);

    if(action==="login") {
      if(!existing) {
        // O cadastro antigo era local. A identidade do proprietário foi verificada acima.
        if(!/^[a-f0-9]{64}$/.test(String(input.legacyHash || "")) || !equalHex(await legacyDigest(email,password),input.legacyHash))
          return accountJson({error:"Não há acesso cadastrado nesta conta. Crie um acesso ou recupere a senha."},404);
      } else {
        const digest=await passwordDigest(password,existing.password_salt);
        if(!equalHex(digest,existing.password_hash))return accountJson({error:"E-mail ou senha incorretos."},401);
        if(existing.email!==verifiedEmail)await env.DB.prepare("UPDATE accounts SET email=?,updated_at=? WHERE id=?").bind(verifiedEmail,new Date().toISOString(),userId).run();
        return accountJson({profile:accountProfile({...existing,email:verifiedEmail},env)});
      }
    }
    if(action==="signup" && existing)return accountJson({error:"Esta conta já tem acesso. Entre ou recupere a senha."},409);
    const fallback=verifiedEmail.split("@")[0];
    const name=String(input.name || existing?.name || fallback).trim().slice(0,100);
    if(name.length<2)return accountJson({error:"Informe o nome do usuário."},400);
    const salt=toHex(crypto.getRandomValues(new Uint8Array(16)));
    const hash=await passwordDigest(password,salt);
    const now=new Date().toISOString();
    if(existing)await env.DB.prepare("UPDATE accounts SET email=?,name=?,password_salt=?,password_hash=?,updated_at=? WHERE id=?").bind(verifiedEmail,name,salt,hash,now,userId).run();
    else await env.DB.prepare("INSERT INTO accounts (id,email,name,password_salt,password_hash,created_at,updated_at) VALUES (?,?,?,?,?,?,?)").bind(userId,verifiedEmail,name,salt,hash,now,now).run();
    return accountJson({profile:accountProfile({id:userId,email:verifiedEmail,name},env),recovered:action==="recover"});
  } catch(error) {
    console.error("account",error);
    return accountJson({error:error instanceof SyntaxError?"Solicitação inválida.":"Não foi possível acessar sua conta. Tente novamente."},error instanceof SyntaxError?400:503);
  }
}
