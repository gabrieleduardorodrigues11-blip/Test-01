const previewJson=(data,status=200)=>Response.json(data,{status,headers:{"Cache-Control":"no-store"}});
const previewHash=async (value)=>[...new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value)))].map((b)=>b.toString(16).padStart(2,"0")).join("");

export async function handlePreview(request,env) {
  const pathname=new URL(request.url).pathname;
  if(!pathname.startsWith("/api/preview"))return null;
  const owner=request.headers.get("oai-authenticated-user-id");
  if(!owner || !/^[a-zA-Z0-9_-]{8,128}$/.test(owner))return previewJson({error:"Entre com sua conta para ver o print."},401);
  const ready=Boolean(env.BUCKET && env.COTA_BROWSER_ACCOUNT_ID && env.COTA_BROWSER_TOKEN);
  if(pathname==="/api/preview/config" && request.method==="GET")return previewJson({available:ready});
  if(pathname!=="/api/preview")return previewJson({error:"Página não encontrada."},404);
  if(request.method==="GET") {
    const key=new URL(request.url).searchParams.get("key") || "";
    if(!/^[a-f0-9]{64}-\d{4}-\d{2}-\d{2}\.png$/.test(key))return previewJson({error:"Print inválido."},400);
    if(!env.BUCKET)return previewJson({error:"Print indisponível."},503);
    const stored=await env.BUCKET.get(`previews/${owner}/${key}`);
    return stored ? new Response(stored.body,{headers:{"Content-Type":"image/png","Cache-Control":"private, max-age=1800","X-Content-Type-Options":"nosniff"}}) : previewJson({error:"Print não encontrado."},404);
  }
  if(request.method!=="POST")return previewJson({error:"Método não permitido."},405);
  if(!ready)return previewJson({error:"A captura de páginas ainda precisa ser ativada."},503);
  if(request.headers.get("content-type")?.split(";")[0]!=="application/json" || Number(request.headers.get("content-length"))>2048)return previewJson({error:"Solicitação inválida."},400);
  try {
    const raw=await request.text();
    if(raw.length>2048)return previewJson({error:"Solicitação inválida."},400);
    const url=String(JSON.parse(raw).url || "");
    if(url.length>1400 || !hostOf(url))return previewJson({error:"Use uma página direta de fornecedor aceito."},400);
    const day=new Date().toISOString().slice(0,10);
    const key=`${await previewHash(url)}-${day}.png`;
    const path=`previews/${owner}/${key}`;
    if(await env.BUCKET.head(path))return previewJson({key,capturedAt:new Date().toISOString(),cached:true});
    const endpoint=`https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(env.COTA_BROWSER_ACCOUNT_ID)}/browser-rendering/screenshot`;
    const result=await timedFetch(endpoint,{
      method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${env.COTA_BROWSER_TOKEN}`},
      body:JSON.stringify({url,viewport:{width:1080,height:780},gotoOptions:{waitUntil:"domcontentloaded",timeout:15000},screenshotOptions:{fullPage:false}})
    },23000);
    if(!result.ok || !(result.headers.get("content-type") || "").includes("image/"))return previewJson({error:"O fornecedor não permitiu capturar a página agora. Abra o link para conferir a oferta."},502);
    const image=await result.arrayBuffer();
    if(image.byteLength<100 || image.byteLength>5000000)return previewJson({error:"Print inválido ou grande demais."},502);
    await env.BUCKET.put(path,image,{httpMetadata:{contentType:"image/png"}});
    return previewJson({key,capturedAt:new Date().toISOString(),cached:false});
  } catch(error) {
    console.error("preview",error);
    return previewJson({error:"Não foi possível capturar a página agora. Tente novamente."},503);
  }
}
