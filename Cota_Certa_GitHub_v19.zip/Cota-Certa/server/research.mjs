const BLOCKED = ["mercadolivre.com", "mercadolivre.com.br", "mercadolibre.com", "olx.com", "olx.com.br", "enjoei.com.br", "shopee.com.br", "shopee.com", "aliexpress.com", "shein.com"];
const DIRECTORY = ["google.com", "brave.com", "duckduckgo.com", "youtube.com", "facebook.com", "instagram.com", "gov.br", "jusbrasil.com.br", "indeed.com", "glassdoor.com.br", "jooble.org", "salario.com.br", "empregabrasil.com.br", "linkedin.com", "cnpja.com", "cnpj.biz", "consultacnpj.com", "informecadastral.com.br", "casadosdados.com.br", "econodata.com.br", "guiadacarreira.com.br"];
const DELIVERY_DESTINATION = {city:"Belo Horizonte",state:"MG",postalCode:"30120-082",reference:"Sistema Divina Providência — Rua dos Caetés, 741, Centro"};

function normalized(value = "") { return String(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(); }
function hostOf(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password || url.port) return "";
    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    if (!/^[a-z0-9.-]+$/.test(host) || !host.includes(".") || /^(localhost|.*\.localhost|.*\.local|.*\.internal|\d+\.\d+\.\d+\.\d+)$/i.test(host)) return "";
    if ([...BLOCKED, ...DIRECTORY].some((domain) => host === domain || host.endsWith(`.${domain}`))) return "";
    return host;
  } catch { return ""; }
}
function priceNumber(text) {
  const raw = String(text).trim();
  if (!/^(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d{2})?$|^\d+(?:\.\d{1,2})?$/.test(raw)) return 0;
  const normalizedPrice = raw.includes(",") ? raw.replace(/\./g, "").replace(",", ".") : /^\d{1,3}(?:\.\d{3})+$/.test(raw) ? raw.replace(/\./g, "") : raw;
  const price = Number(normalizedPrice);
  return Number.isFinite(price) && price >= 1 && price < 100000000 ? Math.round(price * 100) / 100 : 0;
}
function cnpjValid(value) {
  const digits = String(value).replace(/\D/g, "");
  if (digits.length !== 14 || /^(\d)\1+$/.test(digits)) return false;
  const digit = (base, weights) => { const rest = base.split("").reduce((sum, n, index) => sum + Number(n) * weights[index], 0) % 11; return rest < 2 ? 0 : 11 - rest; };
  const first = digit(digits.slice(0, 12), [5,4,3,2,9,8,7,6,5,4,3,2]);
  return digits.endsWith(`${first}${digit(digits.slice(0, 12) + first, [6,5,4,3,2,9,8,7,6,5,4,3,2])}`);
}
function pickCnpj(content) {
  const match = String(content).match(/\b\d{2}[.]?\d{3}[.]?\d{3}[\/]?\d{4}[-]?\d{2}\b/g) || [];
  const valid = [...new Set(match.map((item) => item.replace(/\D/g, "")))].filter(cnpjValid);
  return valid.length === 1 ? valid[0] : "";
}
function matchTitle(title, name) {
  const words = normalized(name).match(/[a-z\d]{3,}/g) || [];
  if (!words.length) return false;
  const titleText = normalized(title);
  return words.filter((word) => titleText.includes(word)).length >= Math.ceil(words.length * 0.65);
}
function extractPrice(content, title, budget) {
  if (!matchTitle(title, budget.name)) return 0;
  const prices = [...String(content).matchAll(/R\$\s*([\d.]+(?:,\d{2})?)/gi)].map((match) => priceNumber(match[1]));
  const distinct = [...new Set(prices.filter(Boolean))];
  // An ambiguous page must never contribute a guessed amount to the average.
  if (distinct.length !== 1) return 0;
  const unit = normalized(budget.unit);
  if (unit === "mes" && !/\/\s*mes|por mes|mensal|ao mes|mensais/.test(normalized(content))) return 0;
  return distinct[0];
}
function getEntries(payload) {
  if (Array.isArray(payload)) return payload;
  for (const key of ["data", "results"]) if (Array.isArray(payload?.[key])) return payload[key];
  return [];
}
function queryFor(budget) {
  const service = budget.type === "Serviço";
  const rental = budget.type === "Aluguel";
  const terms = service ? "prestador de serviço orçamento preço mensal CNPJ Brasil -salário -vagas -emprego" : rental ? "locação preço mensal fornecedor CNPJ Brasil" : "loja do fornecedor direto CNPJ preço R$ estoque Brasil";
  const excluded = BLOCKED.map((domain) => `-site:${domain}`).join(" ");
  // Long descriptions with several unrelated requirements reduce useful matches.
  const details = String(budget.specification || "").trim().slice(0, 90);
  const destination = `${DELIVERY_DESTINATION.city} ${DELIVERY_DESTINATION.state} CEP ${DELIVERY_DESTINATION.postalCode}`;
  return `${budget.name} ${details} ${destination} ${terms} ${excluded}`.slice(0, 600);
}
async function timedFetch(url, init, timeoutMs = 16000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try { return await fetch(url, { ...init, signal: controller.signal }); }
  finally { clearTimeout(timeout); }
}
async function cnpjStatus(cnpj) {
  if (!cnpj) return { active: false, label: "CNPJ não localizado" };
  try {
    const response = await timedFetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`, { headers: { Accept: "application/json", "User-Agent":"Mozilla/5.0 (compatible; CotaCerta/1.0; +https://chatgpt.com/)" } }, 10000);
    if (!response.ok) throw new Error("indisponível");
    const data = await response.json();
    const active = normalized(data.descricao_situacao_cadastral) === "ativa" || Number(data.situacao_cadastral) === 2;
    return { active, label: active ? "ATIVA" : data.descricao_situacao_cadastral || "Não ativa", legalName: data.razao_social || "", checkedAt: new Date().toISOString(), source: "BrasilAPI / cadastro CNPJ" };
  } catch { return { active: false, label: "Consulta indisponível" }; }
}
function htmlText(value = "") {
  return String(value).replace(/<[^>]*>/g, " ").replace(/&(?:amp|quot|apos|lt|gt|nbsp);|&#(?:x[\da-f]+|\d+);/gi, (match) => {
    const named = { "&amp;":"&", "&quot;":"\"", "&apos;":"'", "&lt;":"<", "&gt;":">", "&nbsp;":" " };
    if (named[match.toLowerCase()]) return named[match.toLowerCase()];
    const numeric = match.slice(2,-1), code = numeric[0]?.toLowerCase() === "x" ? parseInt(numeric.slice(1),16) : parseInt(numeric,10);
    return Number.isFinite(code) && code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : " ";
  }).replace(/\s+/g, " ").trim();
}
function searchResultsFromHtml(html) {
  const results = [];
  for (const match of String(html).matchAll(/<a\b[^>]*class=["'][^"']*\bresult__a\b[^"']*["'][^>]*>[^<]*(?:<(?!\/a>)[^>]*>[^<]*)*<\/a>/gi)) {
    const tag = match[0];
    const href = tag.match(/\bhref=["']([^"']+)["']/i)?.[1];
    if (!href) continue;
    let url = htmlText(href);
    try {
      const target = new URL(url, "https://duckduckgo.com");
      url = target.searchParams.get("uddg") || target.href;
    } catch { continue; }
    results.push({ title: htmlText(tag), url });
  }
  return results;
}
function searchResultsFromBrave(html) {
  const results = [];
  for (const match of String(html).matchAll(/<a\b[^>]*href=["'](https:\/\/[^"']+)["'][^>]*target=["']_self["'][^>]*class=["'][^"']*\bl1["'][\s\S]*?<div\b[^>]*class=["']title search-snippet-title[^"']*["'][^>]*title=["']([^"']+)["']/gi)) {
    results.push({url:htmlText(match[1]),title:htmlText(match[2])});
  }
  return results;
}
function productPrice(html, title, budget) {
  if (budget.type === "Serviço" || !matchTitle(title, budget.name)) return 0;
  // Only machine-readable prices on the supplier's fetched product page are eligible.
  const prices = [];
  const itemprop = String(html).match(/<meta\b[^>]*itemprop=["']price["'][^>]*>/i)?.[0];
  const value = itemprop?.match(/\bcontent=["']([\d.,]+)["']/i)?.[1];
  const metaExpiry = String(html).match(/<meta\b[^>]*itemprop=["']priceValidUntil["'][^>]*>/i)?.[0]?.match(/\bcontent=["'](\d{4}-\d{2}-\d{2})["']/i)?.[1];
  if (value && /itemprop=["']priceCurrency["'][^>]*content=["']BRL["']/i.test(html) && (!metaExpiry || metaExpiry >= new Date().toISOString().slice(0,10))) prices.push(priceNumber(value));
  for (const block of String(html).matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      const data = JSON.parse(block[1]);
      const objects = Array.isArray(data) ? data : Array.isArray(data?.["@graph"]) ? data["@graph"] : [data];
      for (const item of objects) {
        if (!String(item?.["@type"] || "").includes("Product") || !matchTitle(item.name || title,budget.name)) continue;
        const offers = Array.isArray(item.offers) ? item.offers : [item.offers];
        const today = new Date().toISOString().slice(0,10);
        const exact = offers.filter((offer) => offer?.priceCurrency === "BRL" && offer?.price != null && (!offer.priceValidUntil || offer.priceValidUntil >= today)).map((offer) => priceNumber(offer.price)).filter(Boolean);
        prices.push(...exact);
      }
    } catch { /* Invalid structured data is not a price source. */ }
  }
  const distinct = [...new Set(prices.filter(Boolean))];
  return distinct.length === 1 ? distinct[0] : 0;
}
function pageMeta(html, property) {
  for (const tag of String(html).match(/<meta\b[^>]*>/gi) || []) {
    const attrs = Object.fromEntries([...tag.matchAll(/([\w:-]+)\s*=\s*["']([^"']*)["']/g)].map((part)=>[part[1].toLowerCase(),part[2]]));
    if ((attrs.property || attrs.name) === property) return htmlText(attrs.content || "");
  }
  return "";
}
function offerTitle(html, fallback) {
  const pageTitle=pageMeta(html,"og:title") || htmlText(String(html).match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "");
  return (pageTitle || fallback).slice(0,180);
}
function offerImage(html,pageUrl,budget) {
  let image="";
  for(const block of String(html).matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      const data=JSON.parse(block[1]);
      const objects=Array.isArray(data)?data:Array.isArray(data?.["@graph"])?data["@graph"]:[data];
      const product=objects.find((item)=>String(item?.["@type"] || "").includes("Product") && matchTitle(item.name || "",budget.name) && item.image);
      image=Array.isArray(product?.image)?product.image[0]:typeof product?.image==="object"?product.image?.url:product?.image;
      if(image)break;
    } catch { /* Um anúncio sem metadados válidos não tem imagem confirmada. */ }
  }
  image ||= pageMeta(html,"og:image");
  try {
    const url=new URL(image,pageUrl);
    return image && hostOf(url.href) && url.href.length<1400 ? url.href : "";
  } catch { return ""; }
}
async function offerPage(url) {
  let current=url;
  for(let redirects=0;redirects<3;redirects++) {
    if(!hostOf(current))return "";
    const response=await timedFetch(current,{redirect:"manual",cache:"no-store",headers:{Accept:"text/html","Cache-Control":"no-cache","User-Agent":"Mozilla/5.0 (compatible; CotaCerta/1.0; +https://chatgpt.com/)"}},12500);
    if([301,302,303,307,308].includes(response.status)) {
      current=new URL(response.headers.get("location") || "",current).href;
      continue;
    }
    if(!response.ok || !(response.headers.get("content-type") || "text/html").includes("html") || Number(response.headers.get("content-length"))>900000)return "";
    const reader=response.body?.getReader();
    if(!reader)return (await response.text()).slice(0,750000);
    const chunks=[];let size=0;
    while(size<750000) {
      const {done,value}=await reader.read();if(done)break;
      chunks.push(value);size+=value.length;
    }
    await reader.cancel().catch(()=>{});
    const buffer=new Uint8Array(Math.min(size,750000));let offset=0;
    for(const chunk of chunks) { const part=chunk.subarray(0,buffer.length-offset);buffer.set(part,offset);offset+=part.length;if(offset>=buffer.length)break; }
    return new TextDecoder().decode(buffer);
  }
  return "";
}
async function supplierCnpj(html,pageUrl) {
  const direct=pickCnpj(html);
  if(direct)return {cnpj:direct,source:"Página do item"};
  const links=[];
  for(const match of String(html).matchAll(/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)) {
    const label=normalized(htmlText(match[2]));
    if(!/quem somos|sobre a empresa|sobre nos|contato|privacidade|termos de uso|dados da empresa/.test(label))continue;
    try {
      const target=new URL(htmlText(match[1]),pageUrl);
      if(hostOf(target.href)===hostOf(pageUrl) && !links.includes(target.href))links.push(target.href);
    } catch { /* Link externo ou inválido. */ }
    if(links.length>=2)break;
  }
  for(const link of links) {
    try {
      const cnpj=pickCnpj(await offerPage(link));
      if(cnpj)return {cnpj,source:"Página institucional do fornecedor"};
    } catch { /* O CNPJ poderá ser verificado manualmente. */ }
  }
  return {cnpj:"",source:""};
}
async function inspectOffer(entry,budget,source) {
  const url=String(entry.url || entry.link || "");
  if(!hostOf(url) || !matchTitle(entry.title || "",budget.name))return null;
  let body="";
  try { body=await offerPage(url); } catch { /* A fonte pode bloquear leitura automática. */ }
  const observedAt=body ? new Date().toISOString() : null;
  const itemName=offerTitle(body,entry.title || budget.name);
  if(!matchTitle(itemName,budget.name))return null;
  const supplierDocument=await supplierCnpj(body,url);
  const cnpj=supplierDocument.cnpj;
  if(!cnpj)return null;
  const status=await cnpjStatus(cnpj);
  if(!status.active || !status.legalName)return null;
  const pagePrice=budget.type==="Serviço" ? extractPrice(htmlText(body).slice(0,15000),itemName,budget) : productPrice(body,itemName,budget);
  return {
    supplier:status.legalName,cnpj,cnpjSource:supplierDocument.source,itemName,price:pagePrice,url,imageUrl:offerImage(body,url,budget),
    priceSource:pagePrice ? "Preço consultado na página do fornecedor" : "Preço não publicado na página",
    priceObservedAt:pagePrice ? observedAt : null,
    evidenceUrl:"",stockNational:false,stockEvidence:"",cnpjStatus:status,
    discoveredAt:observedAt,source:`${source} · CNPJ ativo; vínculo a conferir`
  };
}
async function searchWithoutKey(budget) {
  const place=`${DELIVERY_DESTINATION.city} ${DELIVERY_DESTINATION.state}`;
  const base = budget.type === "Serviço" ? `${budget.name} ${String(budget.specification || "").slice(0,45)} prestador de serviço ${place} orçamento CNPJ -salário -vagas -emprego` : `${budget.name} ${String(budget.specification || "").slice(0,65)} loja fornecedor direto entrega ${place} CNPJ preço Brasil`;
  const terms=`${base} ${BLOCKED.map((domain)=>`-site:${domain}`).join(" ")}`.slice(0,600);
  try {
    let entries = [];
    const goods = budget.type !== "Serviço";
    try {
      const primary = goods ? `https://search.brave.com/search?q=${encodeURIComponent(terms)}` : `https://html.duckduckgo.com/html/?q=${encodeURIComponent(terms)}`;
      const response = await timedFetch(primary, { headers: { Accept:"text/html" } }, 11000);
      if (response.ok) entries = goods ? searchResultsFromBrave((await response.text()).slice(0,500000)) : searchResultsFromHtml((await response.text()).slice(0,200000));
    } catch { /* Use another public search source. */ }
    if (!entries.length) {
      const secondary = goods ? `https://html.duckduckgo.com/html/?q=${encodeURIComponent(terms)}` : `https://search.brave.com/search?q=${encodeURIComponent(terms)}`;
      const response = await timedFetch(secondary, { headers: { Accept:"text/html" } }, 11000);
      if (response.ok) entries = goods ? searchResultsFromHtml((await response.text()).slice(0,200000)) : searchResultsFromBrave((await response.text()).slice(0,500000));
    }
    entries = entries.filter((entry) => {
      if (!hostOf(entry.url)) return false;
      if (budget.type === "Serviço") return matchTitle(entry.title,budget.name) && !/salario|vaga|emprego|edital|concurso|curso|noticia/i.test(normalized(entry.title)) && !/trabalhe[_-]?conosco|\/carreiras?\/|\/vagas?\/|\/cnpj\//i.test(entry.url);
      return matchTitle(entry.title,budget.name);
    });
    const seen = new Set();
    const selected = entries.filter((entry) => { const domain = hostOf(entry.url); if (seen.has(domain)) return false; seen.add(domain); return true; }).slice(0,9);
    const inspected=await Promise.all(selected.map((entry)=>inspectOffer(entry,budget,"Página do fornecedor")));
    const unique=new Set();
    return inspected.filter((offer)=>offer && !unique.has(offer.cnpj) && unique.add(offer.cnpj)).sort((a,b)=>Number(Boolean(b.price))-Number(Boolean(a.price))).slice(0,3);
  } catch { return []; }
}
export async function research(budget, env = {}) {
  const query = queryFor(budget);
  const headers = { Accept: "application/json", "X-Locale": "pt-BR", "X-Timeout": "15", "X-Token-Budget": "4000" };
  if (env.JINA_API_KEY) headers.Authorization = `Bearer ${env.JINA_API_KEY}`;
  let payload;
  try {
    const response = await timedFetch(`https://s.jina.ai/${encodeURIComponent(query)}`, { headers }, 19000);
    if (!response.ok) {
      const found = await searchWithoutKey(budget);
      const detail = response.status === 401 ? "A pesquisa principal exige credencial; foram consultadas fontes públicas disponíveis." : response.status === 429 ? "A fonte principal atingiu o limite de consultas." : "A fonte principal não respondeu.";
      return { query, found, error:found.length ? "" : `${detail} Nenhuma oferta verificável foi encontrada para este item.`, provider:"Busca pública", sourceStatus:response.status, destination:DELIVERY_DESTINATION };
    }
    payload = await response.json();
  } catch { const found = await searchWithoutKey(budget); return { query,found,error:found.length ? "" : "A pesquisa não respondeu e nenhuma oferta verificável foi encontrada para este item.",provider:"Busca pública",destination:DELIVERY_DESTINATION }; }
  const seen = new Set();
  const entries = getEntries(payload).filter((entry) => {
    const domain = hostOf(entry.url || entry.link || "");
    if (!domain || seen.has(domain) || !matchTitle(entry.title || "", budget.name)) return false;
    seen.add(domain);
    return true;
  }).slice(0, 9);
  const suppliers=new Set();
  const found=(await Promise.all(entries.map((entry)=>inspectOffer(entry,budget,"Pesquisa web")))).filter((offer)=>offer && !suppliers.has(offer.cnpj) && suppliers.add(offer.cnpj)).sort((a,b)=>Number(Boolean(b.price))-Number(Boolean(a.price))).slice(0,3);
  if (!found.length) {
    const alternative = await searchWithoutKey(budget);
    return { query,found:alternative,error:alternative.length ? "" : "Nenhum fornecedor com fonte verificável apareceu nesta consulta.",provider:"Busca pública",destination:DELIVERY_DESTINATION };
  }
  return { query, found, error: "",provider:"Pesquisa integrada",destination:DELIVERY_DESTINATION };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== "/api/research") return new Response("Não encontrado", { status: 404 });
    if (request.method !== "POST") return new Response("Método não permitido", { status: 405 });
    if (request.headers.get("content-type")?.split(";")[0] !== "application/json") return new Response("JSON esperado", { status: 415 });
    let body;
    try {
      if (Number(request.headers.get("content-length")) > 8192) throw new Error("grande");
      body = await request.json();
    } catch { return new Response("Solicitação inválida", { status: 400 }); }
    const budget = { name: String(body?.name || "").slice(0, 140).trim(), specification:String(body?.specification || "").slice(0, 800), type: String(body?.type || ""), unit: String(body?.unit || "") };
    if (budget.name.length < 3) return new Response("Item inválido", { status: 400 });
    const result = await research(budget, env);
    return Response.json(result, { headers: { "Cache-Control": "no-store" } });
  }
};
