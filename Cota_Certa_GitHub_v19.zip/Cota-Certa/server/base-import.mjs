// Registro original do Word fornecido pelo proprietário do Site. As validações de fornecedor e estoque são refeitas no portal.
export const baseImport = {
  "id": "afde5947-d941-4a00-bca7-f9d3b8007d0d",
  "itemId": "2dd9ee38-0230-43f0-ae2c-1fab0d444704",
  "filename": "cotacoes-2026-09-17.doc",
  "mimeType": "application/msword",
  "documentBase64": "77u/PCFkb2N0eXBlIGh0bWw+PGh0bWw+PGhlYWQ+PG1ldGEgY2hhcnNldD0idXRmLTgiPjx0aXRsZT5Db3Rhw6fDtWVzPC90aXRsZT48c3R5bGU+QHBhZ2V7c2l6ZTpBNDttYXJnaW46MmNtfWJvZHl7Zm9udC1mYW1pbHk6J1RpbWVzIE5ldyBSb21hbicsc2VyaWY7Zm9udC1zaXplOjEycHQ7Y29sb3I6IzExMX1oMXt0ZXh0LWFsaWduOmNlbnRlcjtmb250LXNpemU6MTZwdDttYXJnaW46MCAwIDZwdH1oMntmb250LXNpemU6MTNwdDttYXJnaW46MThwdCAwIDdwdDtib3JkZXItYm90dG9tOjFweCBzb2xpZCAjNDQ0O3BhZGRpbmctYm90dG9tOjRwdH0uc3VidGl0bGV7dGV4dC1hbGlnbjpjZW50ZXI7bWFyZ2luOjAgMCAyMnB0fS5pdGVtLWRldGFpbHttYXJnaW46NHB0IDB9LnJlZmVyZW5jZXttYXJnaW46MTJwdCAwO3BhZGRpbmc6OHB0IDEwcHQ7Ym9yZGVyLWxlZnQ6M3B0IHNvbGlkICNhYWE7YmFja2dyb3VuZDojZmFmYWZhfS5yZWZlcmVuY2UuYmVzdHtib3JkZXItbGVmdC1jb2xvcjojMTk4MDVjO2JhY2tncm91bmQ6I2YxZmFmNn0ucmVmZXJlbmNlIHB7bWFyZ2luOjAgMCA0cHQ7bGluZS1oZWlnaHQ6Ljh9LnJlZi10aXRsZXtmb250LXdlaWdodDpib2xkO2ZvbnQtc2l6ZToxMHB0O2xldHRlci1zcGFjaW5nOi4zcHR9LnRvdGFse3RleHQtYWxpZ246cmlnaHQ7bWFyZ2luLXRvcDo5cHQ7cGFkZGluZy10b3A6NXB0O2JvcmRlci10b3A6MXB4IHNvbGlkICNhYWF9LnBhZ2Utc3BhY2V7cGFnZS1icmVhay1pbnNpZGU6YXZvaWR9YXtjb2xvcjojMWY0ZTc5fTwvc3R5bGU+PC9oZWFkPjxib2R5PjxoMT5NQVBBIERFIENPVEHDh8OVRVM8L2gxPjxwIGNsYXNzPSJzdWJ0aXRsZSI+RG9jdW1lbnRvIGdlcmFkbyBlbSAxNy8wOS8yMDI2PC9wPjxkaXYgY2xhc3M9Iml0ZW0gIj48aDI+MS4gUlRYIDUwODA8L2gyPjxwIGNsYXNzPSJpdGVtLWRldGFpbCI+PHN0cm9uZz5USVBPOjwvc3Ryb25nPiBBcXVpc2nDp8OjbyBkZSBiZW5zICZuYnNwOyB8ICZuYnNwOyA8c3Ryb25nPkNBVEVHT1JJQTo8L3N0cm9uZz4gRXF1aXBhbWVudG9zPC9wPjxwIGNsYXNzPSJpdGVtLWRldGFpbCI+PHN0cm9uZz5RVUFOVElEQURFOjwvc3Ryb25nPiA1IHVuLjwvcD48cCBjbGFzcz0iaXRlbS1kZXRhaWwiPjxzdHJvbmc+RVNQRUNJRklDQcOHw4NPOjwvc3Ryb25nPiBQbGFjYSBkZSBWw61kZW8gQVNVUyBSVFggNTA4MCBQUklNRSBPQyAxNkcgTlZJRElBIEdlRm9yY2UsIDE2R0IsIEdERFI3LCBHLVN5bmMsIFJheSBUcmFjaW5nLCBETFNTIDQsIEhEUiAtIDkwWVYwTFgwLU0wTkEwMDwvcD48cCBjbGFzcz0iaXRlbS1kZXRhaWwiPjxzdHJvbmc+SU5JQ0lBRE8gRU06PC9zdHJvbmc+IDE3LzA5LzIwMjYsIDA5OjI0ICZuYnNwOyB8ICZuYnNwOyA8c3Ryb25nPkZJTkFMSVpBRE8gRU06PC9zdHJvbmc+IDE3LzA5LzIwMjYsIDA5OjMwPC9wPjxkaXYgY2xhc3M9InJlZmVyZW5jZSBiZXN0Ij48cCBjbGFzcz0icmVmLXRpdGxlIj5SRUZFUsOKTkNJQSAxIOKAlCBNRUxIT1IgT1DDh8ODTzwvcD48cD48c3Ryb25nPk5PTUU6PC9zdHJvbmc+IFRFUkFCWVRFIEFUQUNBRE8gRSBWQVJFSk8gREUgUFJPRFVUT1MgREUgSU5GT1JNQVRJQ0EgTFREQTwvcD48cD48c3Ryb25nPkNOUEo6PC9zdHJvbmc+IDA3Ljk5My45NzMvMDAwMS0xOCDigJQgQVRJVkE8L3A+PHA+PHN0cm9uZz5ESVNQT07DjVZFTCBFTTo8L3N0cm9uZz4gPGEgaHJlZj0iaHR0cHM6Ly93d3cudGVyYWJ5dGVzaG9wLmNvbS5ici9wcm9kdXRvLzM0MDA1L3BsYWNhLWRlLXZpZGVvLWFzdXMtcHJpbWUtbnZpZGlhLWdlZm9yY2UtcnR4LTUwODAtb2MtMTZnYi1nZGRyNy1kbHNzLXJheS10cmFjaW5nLXByaW1lLXJ0eDUwODAtbzE2ZyI+aHR0cHM6Ly93d3cudGVyYWJ5dGVzaG9wLmNvbS5ici9wcm9kdXRvLzM0MDA1L3BsYWNhLWRlLXZpZGVvLWFzdXMtcHJpbWUtbnZpZGlhLWdlZm9yY2UtcnR4LTUwODAtb2MtMTZnYi1nZGRyNy1kbHNzLXJheS10cmFjaW5nLXByaW1lLXJ0eDUwODAtbzE2ZzwvYT48L3A+PHA+PHN0cm9uZz5ESVNQT05JQklMSURBREUgTk8gQlJBU0lMOjwvc3Ryb25nPiBDT01QUk9WQURBIOKAlCA8YSBocmVmPSJodHRwczovL3d3dy50ZXJhYnl0ZXNob3AuY29tLmJyL3Byb2R1dG8vMzQwMDUvcGxhY2EtZGUtdmlkZW8tYXN1cy1wcmltZS1udmlkaWEtZ2Vmb3JjZS1ydHgtNTA4MC1vYy0xNmdiLWdkZHI3LWRsc3MtcmF5LXRyYWNpbmctcHJpbWUtcnR4NTA4MC1vMTZnIj5ldmlkw6puY2lhPC9hPjwvcD48cD48c3Ryb25nPkFDRVNTQURPIEVNOjwvc3Ryb25nPiAxNy8wOS8yMDI2LCAwOToyNTwvcD48cD48c3Ryb25nPlZBTE9SOjwvc3Ryb25nPiBSJMKgMTIuMzQ5LDkwPC9wPjwvZGl2PjxkaXYgY2xhc3M9InJlZmVyZW5jZSAiPjxwIGNsYXNzPSJyZWYtdGl0bGUiPlJFRkVSw4pOQ0lBIDI8L3A+PHA+PHN0cm9uZz5OT01FOjwvc3Ryb25nPiBWRU5UVVJJTkVMTEkgQ09NRVJDSU8gREUgQVJUSUdPUyBQQVJBIElORk9STUFUSUNBIExUREE8L3A+PHA+PHN0cm9uZz5DTlBKOjwvc3Ryb25nPiAwNS40OTQuOTMxLzAwMDEtMDcg4oCUIEFUSVZBPC9wPjxwPjxzdHJvbmc+RElTUE9Ow41WRUwgRU06PC9zdHJvbmc+IDxhIGhyZWY9Imh0dHBzOi8vd3d3LnZlbnR1cmlnYW1pbmcuY29tLmJyL3Byb2R1dG9zL3BsYWNhLWRlLXZpZGVvLWFzdXMtbnZpZGlhLWdlZm9yY2UtcHJpbWUtM3gtcHJldGEtcnR4NTA4MC0xNmdiLWdkcnI3LTI1Ni1iaXRzLXByaW1lLXJ0eC01MDgwLTE2Zy8iPmh0dHBzOi8vd3d3LnZlbnR1cmlnYW1pbmcuY29tLmJyL3Byb2R1dG9zL3BsYWNhLWRlLXZpZGVvLWFzdXMtbnZpZGlhLWdlZm9yY2UtcHJpbWUtM3gtcHJldGEtcnR4NTA4MC0xNmdiLWdkcnI3LTI1Ni1iaXRzLXByaW1lLXJ0eC01MDgwLTE2Zy88L2E+PC9wPjxwPjxzdHJvbmc+RElTUE9OSUJJTElEQURFIE5PIEJSQVNJTDo8L3N0cm9uZz4gQ09NUFJPVkFEQSDigJQgPGEgaHJlZj0iaHR0cHM6Ly93d3cudmVudHVyaWdhbWluZy5jb20uYnIvcHJvZHV0b3MvcGxhY2EtZGUtdmlkZW8tYXN1cy1udmlkaWEtZ2Vmb3JjZS1wcmltZS0zeC1wcmV0YS1ydHg1MDgwLTE2Z2ItZ2RycjctMjU2LWJpdHMtcHJpbWUtcnR4LTUwODAtMTZnLyI+ZXZpZMOqbmNpYTwvYT48L3A+PHA+PHN0cm9uZz5BQ0VTU0FETyBFTTo8L3N0cm9uZz4gMTcvMDkvMjAyNiwgMDk6MjU8L3A+PHA+PHN0cm9uZz5WQUxPUjo8L3N0cm9uZz4gUiTCoDE0LjQwMCw5OTwvcD48L2Rpdj48ZGl2IGNsYXNzPSJyZWZlcmVuY2UgIj48cCBjbGFzcz0icmVmLXRpdGxlIj5SRUZFUsOKTkNJQSAzPC9wPjxwPjxzdHJvbmc+Tk9NRTo8L3N0cm9uZz4ga2FidW08L3A+PHA+PHN0cm9uZz5DTlBKOjwvc3Ryb25nPiAwNS41NzAuNzE0LzAwMDEtNTkg4oCUIEFUSVZBPC9wPjxwPjxzdHJvbmc+RElTUE9Ow41WRUwgRU06PC9zdHJvbmc+IDxhIGhyZWY9Imh0dHBzOi8vd3d3LmthYnVtLmNvbS5ici9wcm9kdXRvLzY5MDM4Mi9wbGFjYS1kZS12aWRlby1hc3VzLXJ0eC01MDgwLXByaW1lLW9jLTE2Zy1udmlkaWEtZ2Vmb3JjZS0xNmdiLWdkZHI3LWctc3luYy1yYXktdHJhY2luZy1kbHNzLTQtaGRyLTkweXYwbHgwLW0wbmEwMCI+aHR0cHM6Ly93d3cua2FidW0uY29tLmJyL3Byb2R1dG8vNjkwMzgyL3BsYWNhLWRlLXZpZGVvLWFzdXMtcnR4LTUwODAtcHJpbWUtb2MtMTZnLW52aWRpYS1nZWZvcmNlLTE2Z2ItZ2RkcjctZy1zeW5jLXJheS10cmFjaW5nLWRsc3MtNC1oZHItOTB5djBseDAtbTBuYTAwPC9hPjwvcD48cD48c3Ryb25nPkRJU1BPTklCSUxJREFERSBOTyBCUkFTSUw6PC9zdHJvbmc+IENPTVBST1ZBREEg4oCUIDxhIGhyZWY9Imh0dHBzOi8vd3d3LmthYnVtLmNvbS5ici9wcm9kdXRvLzY5MDM4Mi9wbGFjYS1kZS12aWRlby1hc3VzLXJ0eC01MDgwLXByaW1lLW9jLTE2Zy1udmlkaWEtZ2Vmb3JjZS0xNmdiLWdkZHI3LWctc3luYy1yYXktdHJhY2luZy1kbHNzLTQtaGRyLTkweXYwbHgwLW0wbmEwMCI+ZXZpZMOqbmNpYTwvYT48L3A+PHA+PHN0cm9uZz5BQ0VTU0FETyBFTTo8L3N0cm9uZz4gMTcvMDkvMjAyNiwgMDk6MjU8L3A+PHA+PHN0cm9uZz5WQUxPUjo8L3N0cm9uZz4gUiTCoDEzLjk5OSw5OTwvcD48L2Rpdj48cCBjbGFzcz0iaXRlbS1kZXRhaWwiPjxzdHJvbmc+TcOJRElBIFVOSVTDgVJJQSAoMy8zLCBDT05GSVJNQURBKTo8L3N0cm9uZz4gUiTCoDEzLjU4Myw2MyAmbmJzcDsgfCAmbmJzcDsgPHN0cm9uZz5NRURJQU5BOjwvc3Ryb25nPiBSJMKgMTMuOTk5LDk5PC9wPjxwIGNsYXNzPSJ0b3RhbCI+PHN0cm9uZz5UT1RBTCBQRUxBIE1FTEhPUiBPUMOHw4NPOjwvc3Ryb25nPiBSJMKgNjEuNzQ5LDUwPC9wPjwvZGl2PjwvYm9keT48L2h0bWw+",
  "item": {
    "name": "RTX 5080",
    "type": "Aquisição de bens",
    "category": "Equipamentos",
    "quantity": 5,
    "unit": "un.",
    "specification": "Placa de Vídeo ASUS RTX 5080 PRIME OC 16G NVIDIA GeForce, 16GB, GDDR7, G-Sync, Ray Tracing, DLSS 4, HDR - 90YV0LX0-M0NA00",
    "references": [
      {
        "supplier": "TERABYTE ATACADO E VAREJO DE PRODUTOS DE INFORMATICA LTDA",
        "cnpj": "07.993.973/0001-18",
        "price": 12349.9,
        "url": "https://www.terabyteshop.com.br/produto/34005/placa-de-video-asus-prime-nvidia-geforce-rtx-5080-oc-16gb-gddr7-dlss-ray-tracing-prime-rtx5080-o16g",
        "evidenceUrl": "https://www.terabyteshop.com.br/produto/34005/placa-de-video-asus-prime-nvidia-geforce-rtx-5080-oc-16gb-gddr7-dlss-ray-tracing-prime-rtx5080-o16g",
        "stockNational": false,
        "cnpjStatus": {
          "active": false,
          "label": "Revalidar CNPJ"
        },
        "discoveredAt": "2026-09-17T12:25:00.000Z",
        "source": "Word importado · preço e disponibilidade a conferir"
      },
      {
        "supplier": "VENTURINELLI COMERCIO DE ARTIGOS PARA INFORMATICA LTDA",
        "cnpj": "05.494.931/0001-07",
        "price": 14400.99,
        "url": "https://www.venturigaming.com.br/produtos/placa-de-video-asus-nvidia-geforce-prime-3x-preta-rtx5080-16gb-gdrr7-256-bits-prime-rtx-5080-16g/",
        "evidenceUrl": "https://www.venturigaming.com.br/produtos/placa-de-video-asus-nvidia-geforce-prime-3x-preta-rtx5080-16gb-gdrr7-256-bits-prime-rtx-5080-16g/",
        "stockNational": false,
        "cnpjStatus": {
          "active": false,
          "label": "Revalidar CNPJ"
        },
        "discoveredAt": "2026-09-17T12:25:00.000Z",
        "source": "Word importado · preço e disponibilidade a conferir"
      },
      {
        "supplier": "kabum",
        "cnpj": "05.570.714/0001-59",
        "price": 13999.99,
        "url": "https://www.kabum.com.br/produto/690382/placa-de-video-asus-rtx-5080-prime-oc-16g-nvidia-geforce-16gb-gddr7-g-sync-ray-tracing-dlss-4-hdr-90yv0lx0-m0na00",
        "evidenceUrl": "https://www.kabum.com.br/produto/690382/placa-de-video-asus-rtx-5080-prime-oc-16g-nvidia-geforce-16gb-gddr7-g-sync-ray-tracing-dlss-4-hdr-90yv0lx0-m0na00",
        "stockNational": false,
        "cnpjStatus": {
          "active": false,
          "label": "Revalidar CNPJ"
        },
        "discoveredAt": "2026-09-17T12:25:00.000Z",
        "source": "Word importado · preço e disponibilidade a conferir"
      }
    ],
    "status": "review",
    "startedAt": "2026-09-17T12:24:00.000Z",
    "finishedAt": "2026-09-17T12:30:00.000Z",
    "comparable": false
  }
};
