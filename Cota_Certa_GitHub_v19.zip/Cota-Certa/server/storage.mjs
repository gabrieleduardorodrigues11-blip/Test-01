import { baseImport } from "./base-import.mjs";

const ITEM_FIELDS = "id,owner_id,name,type,category,quantity,unit,specification,status,started_at,finished_at,created_by,created_by_user_id,updated_at,references_json,research_runs_json,comparable,import_id,deleted_at";
const ITEM_UPSERT = `INSERT INTO items (${ITEM_FIELDS}) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
ON CONFLICT(id) DO UPDATE SET name=excluded.name,type=excluded.type,category=excluded.category,quantity=excluded.quantity,unit=excluded.unit,specification=excluded.specification,status=excluded.status,started_at=excluded.started_at,finished_at=excluded.finished_at,created_by=excluded.created_by,created_by_user_id=excluded.created_by_user_id,updated_at=excluded.updated_at,references_json=excluded.references_json,research_runs_json=excluded.research_runs_json,comparable=excluded.comparable,import_id=excluded.import_id,deleted_at=NULL WHERE items.owner_id=excluded.owner_id`;
const ITEM_SEED = `INSERT OR IGNORE INTO items (${ITEM_FIELDS}) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
const json = (data, status = 200) => Response.json(data, {status, headers:{"Cache-Control":"no-store"}});

function cleanItem(raw, ownerId, importId = null) {
  const now = new Date().toISOString();
  const name = String(raw?.name || "").trim().slice(0,140);
  if (name.length < 2) throw new Error("Um item está sem descrição.");
  const id = /^[a-zA-Z0-9_-]{8,90}$/.test(raw?.id) ? raw.id : crypto.randomUUID();
  const references = Array.isArray(raw.references) ? raw.references.slice(0,3) : [];
  const runs = Array.isArray(raw.researchRuns) ? raw.researchRuns.slice(-40) : [];
  const quantity = Number(raw.quantity);
  return [id,ownerId,name,String(raw.type || "Objeto").slice(0,40),String(raw.category || "Sem categoria").slice(0,80),Number.isFinite(quantity) && quantity > 0 ? quantity : 1,String(raw.unit || "un.").slice(0,24),String(raw.specification || name).slice(0,1000),["draft","researching","review","complete"].includes(raw.status) ? raw.status : "draft",String(raw.startedAt || now).slice(0,40),raw.finishedAt ? String(raw.finishedAt).slice(0,40) : null,String(raw.createdBy || "").slice(0,100),String(raw.createdByUserId || "").slice(0,90),String(raw.updatedAt || now).slice(0,40),JSON.stringify(references),JSON.stringify(runs),raw.comparable ? 1 : 0,importId || (raw.importId ? String(raw.importId).slice(0,90) : null),null];
}
function asItem(row) {
  let references = [], researchRuns = [];
  try { references = JSON.parse(row.references_json || "[]"); researchRuns = JSON.parse(row.research_runs_json || "[]"); } catch { /* Keep the rest of the record accessible. */ }
  return {id:row.id,name:row.name,type:row.type,category:row.category,quantity:row.quantity,unit:row.unit,specification:row.specification,status:row.status,startedAt:row.started_at,finishedAt:row.finished_at,createdBy:row.created_by,createdByUserId:row.created_by_user_id,updatedAt:row.updated_at,references,researchRuns,comparable:Boolean(row.comparable),importId:row.import_id};
}
async function readJson(request, maxBytes = 1048576) {
  if (Number(request.headers.get("content-length")) > maxBytes) throw new Error("Lista muito grande para uma só operação.");
  const raw = await request.text();
  if (raw.length > maxBytes) throw new Error("Lista muito grande para uma só operação.");
  return JSON.parse(raw);
}
function requireUser(request, env) {
  const owner = request.headers.get("oai-authenticated-user-id");
  if (!owner || !/^[a-zA-Z0-9_-]{8,128}$/.test(owner)) throw new Error("AUTH_REQUIRED");
  if (!env.DB) throw new Error("DB_UNAVAILABLE");
  return owner;
}
function isAdministrator(request,env) {
  const ownerEmail=String(env.COTA_BASE_OWNER_EMAIL||"").trim().toLowerCase();
  const visitorEmail=String(request.headers.get("oai-authenticated-user-email")||"").trim().toLowerCase();
  return Boolean(ownerEmail && visitorEmail && ownerEmail===visitorEmail);
}
function changesOf(result) { return Number(result?.meta?.changes ?? result?.changes ?? 0); }
function audit(env,owner,action,entityType,entityId,details={}) {
  return env.DB.prepare("INSERT INTO audit_events (id,owner_id,action,entity_type,entity_id,details_json,created_at) VALUES (?,?,?,?,?,?,?)")
    .bind(crypto.randomUUID(),owner,action,entityType,entityId || null,JSON.stringify(details),new Date().toISOString());
}
async function legacyOwnerIsRecoverable(env,legacyOwner,owner) {
  if(!legacyOwner || legacyOwner===owner)return true;
  return !(await env.DB.prepare("SELECT id FROM accounts WHERE id=? LIMIT 1").bind(legacyOwner).first());
}
async function dataHealth(request,env,owner) {
  if(!isAdministrator(request,env))return json({error:"Somente o administrador pode verificar ou recuperar dados históricos."},403);
  const [importsResult,legacyResult,deletedResult,auditResult]=await Promise.all([
    env.DB.prepare(`SELECT i.id,i.filename,i.mime_type,i.byte_length,i.item_count,i.created_at,COUNT(it.id) AS linked_items
      FROM imports i LEFT JOIN items it ON it.import_id=i.id AND it.deleted_at IS NULL
      WHERE i.owner_id=? GROUP BY i.id,i.filename,i.mime_type,i.byte_length,i.item_count,i.created_at ORDER BY i.created_at DESC LIMIT 100`).bind(owner).all(),
    env.DB.prepare("SELECT id,owner_id,name,updated_at,import_id FROM items WHERE owner_id<>? AND deleted_at IS NULL ORDER BY updated_at DESC LIMIT 3000").bind(owner).all(),
    env.DB.prepare("SELECT id,name,category,deleted_at FROM items WHERE owner_id=? AND deleted_at IS NOT NULL ORDER BY deleted_at DESC LIMIT 100").bind(owner).all(),
    env.DB.prepare("SELECT action,entity_type,entity_id,details_json,created_at FROM audit_events WHERE owner_id=? ORDER BY created_at DESC LIMIT 20").bind(owner).all()
  ]);
  const legacyGroups=new Map();
  for(const row of legacyResult.results) {
    const group=legacyGroups.get(row.owner_id)||{ownerId:row.owner_id,itemCount:0,samples:[],latestAt:row.updated_at,importIds:new Set()};
    group.itemCount++;
    if(group.samples.length<3)group.samples.push(row.name);
    if(row.import_id)group.importIds.add(row.import_id);
    legacyGroups.set(row.owner_id,group);
  }
  const groups=[];
  for(const group of legacyGroups.values())groups.push({...group,importIds:[...group.importIds],recoverable:await legacyOwnerIsRecoverable(env,group.ownerId,owner)});
  const legacyImportsResult=await env.DB.prepare(`SELECT i.id,i.owner_id,i.filename,i.mime_type,i.byte_length,i.item_count,i.created_at,COUNT(it.id) AS linked_items
    FROM imports i LEFT JOIN items it ON it.import_id=i.id AND it.deleted_at IS NULL
    WHERE i.owner_id<>? GROUP BY i.id,i.owner_id,i.filename,i.mime_type,i.byte_length,i.item_count,i.created_at ORDER BY i.created_at DESC LIMIT 100`).bind(owner).all();
  const legacyImports=[];
  for(const row of legacyImportsResult.results)legacyImports.push({...row,recoverable:await legacyOwnerIsRecoverable(env,row.owner_id,owner)});
  const currentImports=importsResult.results.map((row)=>({...row,missingItems:Math.max(0,Number(row.item_count)-Number(row.linked_items))}));
  return json({
    checkedAt:new Date().toISOString(),
    currentImports,
    legacyGroups:groups,
    legacyImports,
    deletedItems:deletedResult.results,
    recentAudit:auditResult.results.map((row)=>{let details={};try{details=JSON.parse(row.details_json||"{}");}catch{}return {...row,details,details_json:undefined};}),
    healthy:!currentImports.some((row)=>row.missingItems>0)&&!groups.length&&!legacyImports.length
  });
}
async function seedOwnerDocument(request,env,owner) {
  const ownerEmail=String(env.COTA_BASE_OWNER_EMAIL||"").trim().toLowerCase();
  const visitorEmail=String(request.headers.get("oai-authenticated-user-email")||"").trim().toLowerCase();
  if(!ownerEmail||visitorEmail!==ownerEmail)return;
  if(!env.BUCKET)throw new Error("BUCKET_UNAVAILABLE");
  const existing=await env.DB.prepare("SELECT id FROM imports WHERE owner_id=? AND filename=? LIMIT 1").bind(owner,baseImport.filename).first();
  if(existing)return;
  const key=`imports/${owner}/${baseImport.id}`;
  const content=Uint8Array.from(atob(baseImport.documentBase64),(char)=>char.charCodeAt(0));
  await env.BUCKET.put(key,content,{httpMetadata:{contentType:baseImport.mimeType}});
  const row=cleanItem({...baseImport.item,id:baseImport.itemId,createdBy:"Importação Word",createdByUserId:owner},owner,baseImport.id);
  try {
    await env.DB.batch([
      env.DB.prepare("INSERT OR IGNORE INTO imports (id,owner_id,filename,mime_type,byte_length,object_key,item_count,created_at) VALUES (?,?,?,?,?,?,?,?)").bind(baseImport.id,owner,baseImport.filename,baseImport.mimeType,content.byteLength,key,1,new Date().toISOString()),
      env.DB.prepare(ITEM_SEED).bind(...row)
    ]);
  } catch(error) {
    if(!await env.DB.prepare("SELECT id FROM imports WHERE id=? AND owner_id=?").bind(baseImport.id,owner).first())await env.BUCKET.delete(key);
    throw error;
  }
}
export async function handleStorage(request, env) {
  const path = new URL(request.url).pathname;
  if (!path.startsWith("/api/items") && !path.startsWith("/api/imports") && !path.startsWith("/api/data-health") && !path.startsWith("/api/data-recovery")) return null;
  let owner;
  try { owner = requireUser(request,env); }
  catch (error) { return json({error:error.message === "AUTH_REQUIRED" ? "Entre no portal para acessar seus itens." : "Banco de dados indisponível. Tente novamente."},error.message === "AUTH_REQUIRED" ? 401 : 503); }
  try {
    if(path==="/api/data-health" && request.method==="GET")return dataHealth(request,env,owner);
    const recoveryDownload=path.match(/^\/api\/data-recovery\/imports\/([a-zA-Z0-9_-]{8,90})\/download$/);
    if(recoveryDownload && request.method==="GET") {
      if(!isAdministrator(request,env))return json({error:"Somente o administrador pode recuperar arquivos históricos."},403);
      const item=await env.DB.prepare("SELECT id,owner_id,filename,mime_type,object_key FROM imports WHERE id=? LIMIT 1").bind(recoveryDownload[1]).first();
      if(!item || !await legacyOwnerIsRecoverable(env,item.owner_id,owner))return json({error:"Arquivo histórico indisponível para recuperação."},404);
      const file=await env.BUCKET?.get(item.object_key);
      if(!file)return json({error:"O arquivo original não foi localizado."},404);
      return new Response(file.body,{headers:{"Content-Type":item.mime_type,"Content-Disposition":`attachment; filename*=UTF-8''${encodeURIComponent(item.filename)}`,"Cache-Control":"private, no-store"}});
    }
    if(path==="/api/data-recovery/adopt-items" && request.method==="POST") {
      if(!isAdministrator(request,env))return json({error:"Somente o administrador pode recuperar itens históricos."},403);
      const input=await readJson(request,8192),legacyOwner=String(input.legacyOwnerId||"");
      if(!/^[a-zA-Z0-9_-]{8,128}$/.test(legacyOwner) || legacyOwner===owner || !await legacyOwnerIsRecoverable(env,legacyOwner,owner))return json({error:"Grupo histórico inválido ou vinculado a outra conta ativa."},409);
      const now=new Date().toISOString();
      const results=await env.DB.batch([
        env.DB.prepare("UPDATE items SET owner_id=?,updated_at=? WHERE owner_id=? AND deleted_at IS NULL").bind(owner,now,legacyOwner),
        env.DB.prepare("UPDATE imports SET owner_id=? WHERE owner_id=?").bind(owner,legacyOwner),
        audit(env,owner,"recover_legacy_items","owner_group",legacyOwner,{sourceOwner:legacyOwner})
      ]);
      return json({recovered:changesOf(results[0]),importsReassigned:changesOf(results[1])});
    }
    if(path==="/api/data-recovery/restore-item" && request.method==="POST") {
      if(!isAdministrator(request,env))return json({error:"Somente o administrador pode restaurar itens."},403);
      const input=await readJson(request,8192),itemId=String(input.itemId||"");
      if(!/^[a-zA-Z0-9_-]{8,90}$/.test(itemId))return json({error:"Item inválido."},400);
      const now=new Date().toISOString();
      const results=await env.DB.batch([
        env.DB.prepare("UPDATE items SET deleted_at=NULL,updated_at=? WHERE id=? AND owner_id=? AND deleted_at IS NOT NULL").bind(now,itemId,owner),
        audit(env,owner,"restore_item","item",itemId,{})
      ]);
      return json({restored:changesOf(results[0])});
    }
    if(path==="/api/items/bulk-delete" && request.method==="POST") {
      if(!isAdministrator(request,env))return json({error:"Somente o administrador pode excluir todos os orçamentos."},403);
      const input=await readJson(request,8192);
      if(String(input.confirmation||"")!=="EXCLUIR TODOS")return json({error:"Digite EXCLUIR TODOS para confirmar."},400);
      const countRow=await env.DB.prepare("SELECT COUNT(*) AS total FROM items WHERE owner_id=? AND deleted_at IS NULL").bind(owner).first();
      const total=Number(countRow?.total)||0;
      if(!total)return json({deleted:0,recoverable:true});
      const now=new Date().toISOString();
      const results=await env.DB.batch([
        env.DB.prepare("UPDATE items SET deleted_at=?,updated_at=? WHERE owner_id=? AND deleted_at IS NULL").bind(now,now,owner),
        audit(env,owner,"soft_delete_all","items",null,{count:total})
      ]);
      return json({deleted:changesOf(results[0]),recoverable:true});
    }
    if (path === "/api/items" && request.method === "GET") {
      let importWarning="";
      try { await seedOwnerDocument(request,env,owner); }
      catch(error) { console.error("base-import",error);importWarning="O Word de cotações ainda não foi carregado. Tente atualizar a página."; }
      const result = await env.DB.prepare(`SELECT ${ITEM_FIELDS} FROM items WHERE owner_id=? AND deleted_at IS NULL ORDER BY updated_at DESC LIMIT 3000`).bind(owner).all();
      return json({items:result.results.map(asItem),importWarning});
    }
    if (path === "/api/items" && request.method === "POST") {
      const input = await readJson(request);
      if (!Array.isArray(input.items) || input.items.length < 1 || input.items.length > 500) return json({error:"Envie entre 1 e 500 itens por lote."},400);
      const rows = input.items.map((entry) => cleanItem(entry,owner));
      await env.DB.batch(rows.map((row) => env.DB.prepare(ITEM_UPSERT).bind(...row)));
      return json({saved:rows.length, ids:rows.map((row) => row[0])});
    }
    const itemMatch = path.match(/^\/api\/items\/([a-zA-Z0-9_-]{8,90})$/);
    if (itemMatch && request.method === "DELETE") {
      const now=new Date().toISOString();
      const results=await env.DB.batch([
        env.DB.prepare("UPDATE items SET deleted_at=?,updated_at=? WHERE id=? AND owner_id=? AND deleted_at IS NULL").bind(now,now,itemMatch[1],owner),
        audit(env,owner,"soft_delete","item",itemMatch[1],{})
      ]);
      return json({deleted:changesOf(results[0])>0,recoverable:true});
    }
    if (path === "/api/imports" && request.method === "GET") {
      const result = await env.DB.prepare("SELECT id,filename,mime_type,byte_length,item_count,created_at FROM imports WHERE owner_id=? ORDER BY created_at DESC LIMIT 100").bind(owner).all();
      return json({imports:result.results});
    }
    if (path === "/api/imports" && request.method === "POST") {
      if (!env.BUCKET) return json({error:"Armazenamento de arquivos indisponível."},503);
      if (Number(request.headers.get("content-length")) > 12000000) return json({error:"Arquivo maior que 10 MB."},413);
      const form = await request.formData();
      const file = form.get("file");
      if (!file || typeof file.arrayBuffer !== "function" || file.size > 10000000) return json({error:"Selecione um arquivo de até 10 MB."},400);
      if (!/\.(csv|tsv|txt|xlsx|docx|doc|pdf)$/i.test(file.name || "")) return json({error:"Formato aceito: CSV, TSV, TXT, XLSX, DOCX, DOC exportado pelo Cota Certa ou PDF."},400);
      let input;
      try { input = JSON.parse(String(form.get("items") || "[]")); } catch { return json({error:"A lista extraída do arquivo é inválida."},400); }
      if (!Array.isArray(input) || input.length < 1 || input.length > 500) return json({error:"O arquivo precisa ter entre 1 e 500 itens reconhecidos."},400);
      const id = crypto.randomUUID(), key = `imports/${owner}/${id}`, createdAt = new Date().toISOString();
      const rows = input.map((entry) => cleanItem({...entry,id:crypto.randomUUID(),startedAt:entry.startedAt || createdAt,updatedAt:createdAt},owner,id));
      await env.BUCKET.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:file.type || "application/octet-stream"}});
      try {
        const statements = [env.DB.prepare("INSERT INTO imports (id,owner_id,filename,mime_type,byte_length,object_key,item_count,created_at) VALUES (?,?,?,?,?,?,?,?)").bind(id,owner,String(file.name).slice(0,220),String(file.type || "application/octet-stream"),file.size,key,rows.length,createdAt),...rows.map((row) => env.DB.prepare(ITEM_UPSERT).bind(...row))];
        await env.DB.batch(statements);
      } catch (error) { await env.BUCKET.delete(key); throw error; }
      return json({importId:id, imported:rows.length, ids:rows.map((row) => row[0])},201);
    }
    const importMatch = path.match(/^\/api\/imports\/([a-zA-Z0-9_-]{8,90})\/download$/);
    if (importMatch && request.method === "GET") {
      const item = await env.DB.prepare("SELECT filename,mime_type,object_key FROM imports WHERE id=? AND owner_id=?").bind(importMatch[1],owner).first();
      if (!item) return json({error:"Arquivo não encontrado."},404);
      const file = await env.BUCKET.get(item.object_key);
      if (!file) return json({error:"Arquivo não encontrado."},404);
      return new Response(file.body,{headers:{"Content-Type":item.mime_type,"Content-Disposition":`attachment; filename*=UTF-8''${encodeURIComponent(item.filename)}`,"Cache-Control":"private, no-store"}});
    }
    return json({error:"Rota não encontrada."},404);
  } catch (error) {
    const message = error instanceof SyntaxError ? "Arquivo ou dados inválidos." : /Lista muito grande|sem descrição/.test(error.message || "") ? error.message : "Não foi possível salvar ou carregar os dados. Tente novamente.";
    console.error("storage",path,error);
    return json({error:message},message === "Não foi possível salvar ou carregar os dados. Tente novamente." ? 503 : 400);
  }
}
