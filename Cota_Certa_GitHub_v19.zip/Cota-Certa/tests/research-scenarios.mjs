import assert from "node:assert/strict";
import { research } from "../server/research.mjs";

const originalFetch = globalThis.fetch;
const validCnpj = "11222333000181";
let current = null;
let pageRequests = 0;
const product = "Caneta esferográfica azul";
const page = (price, content = "") => `<html><head><meta property="og:title" content="${product} - fornecedor" />${content}</head><body>CNPJ ${validCnpj}</body></html>`;
const meta = (price) => `<meta itemprop="priceCurrency" content="BRL" /><meta itemprop="price" content="${price}" />`;
const jsonLd = (price) => `<script type="application/ld+json">${JSON.stringify({"@type":"Product",name:product,offers:{priceCurrency:"BRL",price}})}</script>`;

globalThis.fetch = async (url, options = {}) => {
  const address = String(url);
  if (address.startsWith("https://s.jina.ai/")) {
    const blocked = current.variant === 5;
    const entries = [{title:`${product} | fornecedor`,url:blocked?"https://shopee.com.br/oferta":"https://fornecedor.example.com/item",content:"R$ 9,00 CNPJ 11222333000181 (resultado antigo)"}];
    if (current.variant === 8) entries.push({title:`${product} | outra vitrine`,url:"https://outra.example.com/item"});
    return Response.json({data:entries});
  }
  if (address.startsWith("https://search.brave.com/") || address.startsWith("https://html.duckduckgo.com/")) return new Response("",{headers:{"content-type":"text/html"}});
  if (address.startsWith("https://brasilapi.com.br/")) return Response.json({descricao_situacao_cadastral:current.variant===7?"INAPTA":"ATIVA",razao_social:"Fornecedor direto Ltda"});
  if (address.startsWith("https://fornecedor.example.com/") || address.startsWith("https://outra.example.com/")) {
    pageRequests++;
    assert.equal(options.cache,"no-store","consulta deve dispensar cache do cliente");
    if (current.variant===9) return new Response("Bloqueado",{status:503});
    if (current.variant===6) return new Response(`<html><title>${product}</title><body>CNPJ inválido</body></html>`,{headers:{"content-type":"text/html"}});
    let markup="";
    if ([0,8].includes(current.variant)) markup=jsonLd(current.price);
    if (current.variant===1) markup=meta(current.price);
    if (current.variant===3) markup=meta(current.price)+jsonLd(current.price+10);
    if (current.variant===4) markup=meta(current.price)+'<meta itemprop="priceValidUntil" content="2001-01-01" />';
    if (current.variant===7) markup=meta(current.price);
    return new Response(page(current.price,markup),{headers:{"content-type":"text/html"}});
  }
  throw new Error(`Requisição inesperada: ${address}`);
};

try {
  const start = Date.now();
  for (let i=0;i<1000;i++) {
    current={variant:i%10,price:Math.round((1000+i/100)*100)/100};
    const outcome=await research({name:product,type:"Aquisição de bens",unit:"un.",specification:`Ponta média lote ${i}`},{JINA_API_KEY:"test-key"});
    assert.equal(outcome.destination.postalCode,"30120-082",`cenário ${i}`);
    assert.match(outcome.query,/Belo Horizonte MG CEP 30120-082/,`cenário ${i}`);
    const expectedCount=[0,1,2,3,4,7,8].includes(current.variant) ? (current.variant===7?0:1) : 0;
    assert.equal(outcome.found.length,expectedCount,`cenário ${i}: variante ${current.variant}`);
    if (expectedCount) {
      const offer=outcome.found[0];
      const expectedPrice=[0,1,8].includes(current.variant)?current.price:0;
      assert.equal(offer.price,expectedPrice,`cenário ${i}: preço fora da página, ambíguo ou expirado`);
      assert.equal(Boolean(offer.priceObservedAt),Boolean(expectedPrice),`cenário ${i}: registro de hora incorreto`);
      assert.equal(offer.cnpj,validCnpj,`cenário ${i}: CNPJ não vem da página`);
      assert.equal(offer.stockNational,false,`cenário ${i}: estoque sem prova`);
      assert.ok(!offer.url.includes("shopee"),`cenário ${i}: marketplace aceito`);
    }
  }
  console.log(JSON.stringify({suite:"pesquisa de preços",scenarios:1000,groups:10,pageRequests,elapsedMs:Date.now()-start,status:"PASS"}));
} finally { globalThis.fetch=originalFetch; }
