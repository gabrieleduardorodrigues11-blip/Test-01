import assert from "node:assert/strict";
import worker from "../dist/server/index.js";

const cnpj = "11222333000181";
const secondCnpj = "22333444000181";
const thirdCnpj = "33444555000181";
const originalFetch = globalThis.fetch;
let fallbackSource = "brave";
let jinaFallback = false;
globalThis.fetch = async (url) => {
  if (String(url).startsWith("https://s.jina.ai/") && jinaFallback) return new Response("Limited",{status:429});
  if (String(url).startsWith("https://s.jina.ai/")) return Response.json({ data: [
    {title:"Balança digital de plataforma 300 kg | Loja Alfa",url:"https://alfa.com.br/balanca",content:`Balança digital de plataforma 300 kg R$ 1.890,00 CNPJ ${cnpj}`},
    {title:"Balança digital de plataforma 300 kg | OLX",url:"https://olx.com.br/oferta",content:"R$ 500,00"},
    {title:"Balança digital de plataforma 300 kg | Shopee",url:"https://shopee.com.br/oferta",content:"R$ 800,00"},
    {title:"Balança digital de plataforma 300 kg | Enjoei",url:"https://enjoei.com.br/oferta",content:"R$ 800,00"},
    {title:"Balança digital de plataforma 300 kg | Amazon",url:"https://amazon.com.br/oferta",content:"R$ 800,00"},
    {title:"Balança digital de plataforma 300 kg | Loja Beta",url:"https://beta.com.br/balanca",content:"R$ 1.400,00 R$ 2.500,00"},
    {title:"Balança digital de plataforma 300 kg | Loja Gama",url:"https://gama.com.br/balanca",content:`Balança digital de plataforma 300 kg R$ 1.700,00 CNPJ ${thirdCnpj}`}
  ] });
  if (String(url).startsWith("https://html.duckduckgo.com/") && String(url).includes("Coordenador%20Cultural")) return new Response(`
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fartex.art.br%2F">Coordenador Cultural projetos - Artex</a>
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fguiadacarreira.com.br%2Fguia">Coordenador Cultural - guia de carreira</a>
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fsemcnpj.com.br%2F">Coordenador Cultural consultoria</a>`,{headers:{"content-type":"text/html"}});
  if (String(url).startsWith("https://html.duckduckgo.com/") && fallbackSource === "brave") return new Response("Tente novamente",{status:202});
  if (String(url).startsWith("https://search.brave.com/") && fallbackSource === "duckduckgo") return new Response("Tente novamente",{status:202});
  if (String(url).startsWith("https://search.brave.com/")) return new Response(`<div class="snippet" data-type="web"><a href="https://alfa.com.br/balanca" target="_self" class="svelte-test l1"><div class="title search-snippet-title" title="Balança digital de plataforma 300 kg - Alfa">Balança digital</div></a></div><div class="snippet" data-type="web"><a href="https://beta.com.br/balanca" target="_self" class="svelte-test l1"><div class="title search-snippet-title" title="Balança digital de plataforma 300 kg - Beta">Balança digital</div></a></div>`,{headers:{"content-type":"text/html"}});
  if (String(url).startsWith("https://html.duckduckgo.com/")) return new Response(`
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Falfa.com.br%2Fbalanca">Balança digital de plataforma 300 kg - Alfa</a>
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fmercadolivre.com.br%2Fproduto">Balança digital de plataforma 300 kg - Mercado Livre</a>
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Finformecadastral.com.br%2Fcnpj%2Fempresa">Balança digital de plataforma 300 kg - Diretório</a>
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fbeta.com.br%2Fbalanca">Balança digital de plataforma 300 kg - Beta</a>`,{headers:{"content-type":"text/html"}});
  if (String(url).startsWith("https://alfa.com.br/")) return new Response(`<html><head><meta property="og:title" content="Balança digital de plataforma 300 kg - Alfa" /><meta property="og:image" content="https://cdn.alfa.com.br/foto.jpg" /><meta itemprop="priceCurrency" content="BRL" /><meta itemprop="price" content="1890" /></head><body>CNPJ ${cnpj}</body></html>`,{headers:{"content-type":"text/html"}});
  if (String(url)==="https://beta.com.br/sobre") return new Response(`<html><body>CNPJ ${secondCnpj}. Beta Equipamentos Ltda.</body></html>`,{headers:{"content-type":"text/html"}});
  if (String(url).startsWith("https://beta.com.br/")) return new Response('<html><body>Sem preço divulgado <a href="/sobre">Quem somos</a></body></html>',{headers:{"content-type":"text/html"}});
  if (String(url).startsWith("https://gama.com.br/")) return new Response(`<html><head><meta itemprop="priceCurrency" content="BRL" /><meta itemprop="price" content="1700" /></head><body>CNPJ ${thirdCnpj}</body></html>`,{headers:{"content-type":"text/html"}});
  if (String(url).startsWith("https://artex.art.br/")) return new Response(`<html><body>Coordenação de projetos culturais. CNPJ ${cnpj}</body></html>`,{headers:{"content-type":"text/html"}});
  if (String(url).startsWith("https://semcnpj.com.br/")) return new Response(`<html><body>Consultoria cultural sem identificação cadastral.</body></html>`,{headers:{"content-type":"text/html"}});
  if (String(url).startsWith("https://brasilapi.com.br/")) return Response.json({ descricao_situacao_cadastral:"ATIVA",razao_social:String(url).includes(secondCnpj)?"Beta Equipamentos Ltda":String(url).includes(thirdCnpj)?"Gama Equipamentos Ltda":"Alfa Equipamentos Ltda" });
  throw new Error("URL inesperada");
};
try {
  const response = await worker.fetch(new Request("https://portal.example/api/research", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:"Balança digital de plataforma 300 kg",type:"Aquisição de bens",unit:"un."})}), {JINA_API_KEY:"test-key"});
  assert.equal(response.status, 200);
  const result = await response.json();
  assert.deepEqual(result.destination,{city:"Belo Horizonte",state:"MG",postalCode:"30120-082",reference:"Sistema Divina Providência — Rua dos Caetés, 741, Centro"});
  assert.match(result.query,/Belo Horizonte MG CEP 30120-082/);
  assert.match(result.query,/-site:shopee\.com\.br/);
  assert.doesNotMatch(result.query,/-site:amazon\.com/);
  assert.doesNotMatch(result.query,/-site:magazineluiza\.com\.br/);
  assert.equal(result.found.length, 3);
  assert.equal(result.found[0].price, 1890);
  assert.ok(Number.isFinite(Date.parse(result.found[0].priceObservedAt)));
  assert.equal(result.found[0].priceSource,"Preço consultado na página do fornecedor");
  assert.equal(result.found[0].itemName,"Balança digital de plataforma 300 kg - Alfa");
  assert.equal(result.found[0].imageUrl,"https://cdn.alfa.com.br/foto.jpg");
  assert.equal(result.found[0].supplier,"Alfa Equipamentos Ltda");
  assert.equal(result.found[1].price,1700);
  assert.equal(result.found[2].price,0);
  assert.equal(result.found[2].priceObservedAt,null);
  assert.equal(result.found[2].cnpjSource,"Página institucional do fornecedor");
  assert.ok(result.found.every((ref)=>ref.cnpjStatus.active && !/shopee|enjoei|olx/i.test(ref.url)));
  assert.equal(result.found[0].cnpjStatus.active, true);
  assert.equal(result.found[0].stockNational, false);
  assert.equal(result.found[0].evidenceUrl, "");
  const service = await worker.fetch(new Request("https://portal.example/api/research", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:"Balança digital de plataforma 300 kg",type:"Serviço",unit:"mês"})}), {JINA_API_KEY:"test-key"});
  assert.equal((await service.json()).found[0].price, 0);
  const anonymous = await worker.fetch(new Request("https://portal.example/api/research", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:"Balança digital de plataforma 300 kg",type:"Aquisição de bens",unit:"un."})}), {});
  assert.equal((await anonymous.json()).found[0].price,1890);
  jinaFallback = true;
  const fallback = await worker.fetch(new Request("https://portal.example/api/research", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:"Balança digital de plataforma 300 kg",type:"Aquisição de bens",unit:"un."})}), {});
  const fallbackResult = await fallback.json();
  assert.equal(fallbackResult.destination.postalCode,"30120-082");
  assert.equal(fallbackResult.found.length, 2);
  assert.equal(fallbackResult.found[0].price,1890);
  assert.equal(fallbackResult.found[0].cnpjStatus.active,true);
  assert.equal(fallbackResult.found[1].price,0);
  const serviceFallback = await worker.fetch(new Request("https://portal.example/api/research", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:"Coordenador Cultural",type:"Serviço",unit:"mês"})}), {});
  const serviceFound = (await serviceFallback.json()).found;
  assert.equal(serviceFound.length, 1);
  assert.equal(serviceFound[0].cnpjStatus.active, true);
  assert.equal(serviceFound[0].price, 0);
  fallbackSource = "duckduckgo";
  const duckduckgo = await worker.fetch(new Request("https://portal.example/api/research", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:"Balança digital de plataforma 300 kg",type:"Aquisição de bens",unit:"un."})}), {});
  assert.equal((await duckduckgo.json()).found[0].price,1890);
  const status = await worker.fetch(new Request(`https://portal.example/api/cnpj?cnpj=${cnpj}`), {});
  assert.equal((await status.json()).active, true);
  assert.equal((await worker.fetch(new Request("https://portal.example/app.js"), {})).status, 200);
  console.log("API de pesquisa: filtros, preços ambíguos e validação verificados");
} finally { globalThis.fetch = originalFetch; }
