const { JSDOM } = require("jsdom");
const JSZip = require("jszip");
const fs = require("fs");
const crypto = require("crypto");

function cnpj(base) {
  const digit = (text, weights) => {
    const sum = text.split("").reduce((total, value, i) => total + Number(value) * weights[i], 0);
    return sum % 11 < 2 ? 0 : 11 - (sum % 11);
  };
  const first = digit(base, [5,4,3,2,9,8,7,6,5,4,3,2]);
  return `${base}${first}${digit(base + first, [6,5,4,3,2,9,8,7,6,5,4,3,2])}`;
}

const ids = [cnpj("112223330001"), cnpj("223334440001"), cnpj("334445550001")];
const results = [
  ["Papelaria Horizonte", "papelaria-horizonte.com.br", ids[0], "1.890,00"],
  ["Distribuidora Central", "distribuidora-central.com.br", ids[1], "1.650,00"],
  ["Comercial Minas", "comercial-minas.com.br", ids[2], "1.740,00"]
].map(([title, domain, id, price]) => ({ title, url: `https://${domain}/balanca?origem=busca`, content: `CNPJ ${id} em estoque no Brasil R$ ${price}` }));

const dom = new JSDOM(fs.readFileSync("dist/index.html", "utf8"), { url: "https://cota-certa.example.com", runScripts: "dangerously" });
const { window } = dom;
const { document } = window;
const downloads = [];
Object.defineProperty(window, "crypto", { value: crypto.webcrypto });
Object.assign(window, { JSZip, Blob: global.Blob, TextEncoder: global.TextEncoder, AbortController: global.AbortController, confirm: () => true });
window.File.prototype.text = function () { return new Promise((resolve,reject)=>{const reader=new window.FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error);reader.readAsText(this);}); };
window.File.prototype.arrayBuffer = function () { return new Promise((resolve,reject)=>{const reader=new window.FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error);reader.readAsArrayBuffer(this);}); };
window.eval(fs.readFileSync("dist/import.js", "utf8"));
window.HTMLElement.prototype.scrollIntoView = () => {};
window.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
window.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
window.URL.createObjectURL = (blob) => { downloads.push(blob); return `blob:test-${downloads.length}`; };
window.URL.revokeObjectURL = () => {};
window.HTMLAnchorElement.prototype.click = function () {};
let serviceMode = false;
let firstPrice = 1890;
let noResults = false;
let savedItems=[];
let account=null;
window.fetch = async (url,options={}) => {
  if(String(url)==="/api/account") {
    if(options.method==="POST") {
      const body=JSON.parse(options.body);
      if(body.email!=="biel@example.com")return Response.json({error:"E-mail não verificado."},{status:403});
      if(body.action==="login") {
        if(!account || account.password!==body.password)return Response.json({error:"E-mail ou senha incorretos."},{status:401});
      } else if(body.action==="signup" && account)return Response.json({error:"Já cadastrado."},{status:409});
      else account={password:body.password,profile:{id:"user_biel123",email:body.email,name:body.name || account?.profile.name || "Biel Rodrigues",role:"Administrador"}};
      return Response.json({profile:account.profile});
    }
    return Response.json({email:"biel@example.com",registered:Boolean(account),profile:account?.profile});
  }
  if(String(url)==="/api/preview/config")return Response.json({available:true});
  if(String(url)==="/api/preview" && options.method==="POST")return Response.json({key:"a".repeat(64)+"-2026-09-18.png",capturedAt:"2026-09-18T10:00:00.000Z"});
  if(String(url)==="/api/data-health")return Response.json({checkedAt:new Date().toISOString(),currentImports:[{id:"import_health_123",filename:"lista-65.pdf",item_count:65,linked_items:0,missingItems:65}],legacyGroups:[{ownerId:"legacy_owner_123",itemCount:3,samples:["Lápis","Cadeira"],recoverable:true}],legacyImports:[],deletedItems:[{id:"deleted_item_123",name:"Item excluído",deleted_at:new Date().toISOString()}],healthy:false});
  if(String(url)==="/api/items/bulk-delete"&&options.method==="POST") {const deleted=savedItems.length;savedItems=[];return Response.json({deleted,recoverable:true});}
  if(String(url)==="/api/items") {
    if(options.method==="POST") {for(const item of JSON.parse(options.body).items){savedItems=savedItems.filter((saved)=>saved.id!==item.id);savedItems.push(item);}return Response.json({saved:true});}
    return Response.json({items:savedItems});
  }
  if(String(url).startsWith("/api/items/")&&options.method==="DELETE") {savedItems=savedItems.filter((item)=>item.id!==String(url).split("/").at(-1));return Response.json({deleted:true});}
  if(String(url)==="/api/imports"&&options.method==="POST") {
    const records=JSON.parse(options.body.get("items"));const ids=records.map((_,index)=>`imported_${Date.now()}_${index}`);
    savedItems.push(...records.map((record,index)=>({...record,id:ids[index],status:"draft",startedAt:new Date().toISOString(),updatedAt:new Date().toISOString(),researchRuns:[]})));
    return Response.json({imported:records.length,ids}, {status:201});
  }
  if(String(url)==="/api/research") return new Response(JSON.stringify(serviceMode ? { query:"Coordenador Cultural", destination:{city:"Belo Horizonte",state:"MG",postalCode:"30120-082"}, found:[{ supplier:"Empresa Cultural",cnpj:ids[0],price:0,url:"https://empresa-cultural.com.br/",evidenceUrl:"",stockNational:false,cnpjStatus:{active:true,label:"ATIVA"},source:"Página do fornecedor" }] } : { query:"Balança", destination:{city:"Belo Horizonte",state:"MG",postalCode:"30120-082"}, found:noResults?[]:results.map((entry, index) => ({supplier:entry.title,itemName:"Balança digital de plataforma 300 kg",imageUrl:index===0?"https://papelaria-horizonte.com.br/foto.jpg":"",priceSource:"Preço consultado na página do fornecedor",priceObservedAt:[firstPrice,1650,1740][index]>0?new Date().toISOString():null,cnpj:ids[index],price:[firstPrice,1650,1740][index],url:entry.url,evidenceUrl:"",stockNational:false,cnpjStatus:{active:true,label:"ATIVA"},source:"Pesquisa web"})) }), { status: 200 });
  return new Response(JSON.stringify({ active:true,label:"ATIVA", legalName:"Empresa ativa" }), { status: 200 });
};
window.eval(fs.readFileSync("dist/app.js", "utf8"));

const set = (selector, value) => { const input = document.querySelector(selector); input.value = value; input.dispatchEvent(new window.Event("input", { bubbles: true })); };
const click = (selector) => document.querySelector(selector).dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
const submit = (selector) => document.querySelector(selector).dispatchEvent(new window.Event("submit", { bubbles: true, cancelable: true }));
const waitFor = async (predicate, timeout = 5000) => {
  const start = Date.now();
  while (!predicate()) { if (Date.now() - start > timeout) throw new Error("Tempo excedido"); await new Promise((resolve) => setTimeout(resolve, 20)); }
};

(async () => {
  await waitFor(() => !document.querySelector("#auth-form").hidden);
  set("#auth-name", "Biel Rodrigues"); set("#auth-email", "biel@example.com"); set("#auth-password", "senha123"); submit("#auth-form");
  await waitFor(() => !document.querySelector("#app-shell").hidden);
  await waitFor(() => document.querySelector("#sync-state").textContent.includes("salvos"));
  if (document.querySelector("#user-role").textContent !== "Administrador") throw new Error("Falha no cadastro/login");

  click("#open-budget-modal"); set("#budget-name", "Balança digital de plataforma 300 kg"); set("#budget-category", "Equipamentos"); set("#budget-quantity", "2"); set("#budget-specification", "Capacidade nominal 300 kg para triagem e pesagem"); submit("#budget-form");
  await waitFor(() => !document.querySelector("#research-body").hidden);
  if (document.querySelectorAll(".reference-card").length !== 3) throw new Error("Não gerou 3 referências");
  if(document.querySelector("[name='item-0']").value!=="Balança digital de plataforma 300 kg" || !document.querySelector(".offer-picture[src='https://papelaria-horizonte.com.br/foto.jpg']"))throw new Error("Prévia não mostra item e imagem");
  if(document.querySelector(".source-link").textContent.includes("?origem=") || !document.querySelector(".source-link").href.includes("?origem="))throw new Error("Link exibido não foi resumido sem perder destino");
  click(".capture-offer");
  await waitFor(()=>Boolean(document.querySelector(".offer-picture.screenshot")));
  if (![...document.querySelectorAll(".verification")].every((node) => node.textContent === "ATIVA")) throw new Error("CNPJ sem validação ativa");
  if (![...document.querySelectorAll("[name^='stock-']")].every((input) => !input.checked)) throw new Error("Estoque não deve ser marcado automaticamente");
  if (!document.querySelector("#average-value").textContent.includes("1.760,00") || !document.querySelector("#average-explanation").textContent.includes("Prévia")) throw new Error("Prévia da média incorreta");
  firstPrice = 1990; click("#retry-search"); await waitFor(() => document.querySelector("[name='price-0']").value === "1990,00");
  firstPrice = 1890; click("#retry-search"); await waitFor(() => document.querySelector("[name='price-0']").value === "1890,00");
  noResults=true;click("#retry-search");await waitFor(()=>document.querySelector("#average-value").textContent==="—" && !document.querySelector("#research-body").hidden);
  if(document.querySelector(".reference-card")||!document.querySelector(".reference-empty")||document.querySelectorAll(".research-status-item.missing").length!==3)throw new Error("Busca sem ofertas criou fichas vazias ou não mostrou as pendências");
  const emptyDashboardCard=[...document.querySelectorAll(".budget-card")].find((card)=>card.querySelector("h3")?.textContent.includes("Balança digital"));
  if(!emptyDashboardCard||emptyDashboardCard.querySelector(".quote-preview")||emptyDashboardCard.textContent.includes("Fornecedor pendente"))throw new Error("Lista principal ainda apresentou fornecedores vazios");
  if(document.querySelector("#work-status-panel").hidden||document.querySelector("#work-pending-count").textContent!=="1"||!document.querySelector("#work-pending-list").textContent.includes("Balança digital"))throw new Error("Painel lateral não mostrou o orçamento não feito");
  noResults=false;click("#retry-search");await waitFor(()=>document.querySelector("[name='price-0']")?.value==="1890,00");
  set("[name='supplier-0']", "Fornecedor revisado"); click("#retry-search"); await waitFor(() => !document.querySelector("#research-body").hidden);
  if (document.querySelector("[name='supplier-0']").value !== "Fornecedor revisado") throw new Error("Pesquisa novamente apagou uma alteração manual");
  firstPrice = 0; click("#retry-search"); await waitFor(() => document.querySelector("[name='price-0']").value === "");
  if(!document.querySelector("#average-value").textContent.includes("1.695,00") || !document.querySelector("#research-notice").classList.contains("warning"))throw new Error("Preço anterior foi reutilizado após página deixar de publicar valor");
  firstPrice = 1890; click("#retry-search"); await waitFor(() => document.querySelector("[name='price-0']").value === "1890,00");
  if(document.querySelector("[name^='evidence-']"))throw new Error("Campo separado de evidência ainda aparece");
  for (let index=0; index<3; index++) click(`[name='stock-${index}']`);
  click("#same-scope");
  if (!document.querySelector("#average-explanation").textContent.includes("confirmada")) throw new Error("Média confirmada incorreta");

  for(const allowed of ["https://www.amazon.com.br/produto","https://www.magazineluiza.com.br/produto","https://www.casasbahia.com.br/produto"]) {
    set("[name='url-0']",allowed);click("#save-review");
    if(!document.querySelector("#quotes-alert").hidden)throw new Error(`Loja on-line permitida foi bloqueada: ${allowed}`);
  }

  for(const hostname of ["mercadolivre.com.br","shopee.com.br","olx.com.br","enjoei.com.br"]) {
    set("[name='url-0']", `https://www.${hostname}/produto`);click("#finalize-budget");
    if(document.querySelector("#quotes-alert").hidden)throw new Error(`Marketplace ${hostname} não foi bloqueado`);
  }
  set("[name='url-0']", results[0].url); click("#finalize-budget");
  await waitFor(() => !document.querySelector("#research-dialog").open);
  if (document.querySelector("#metric-complete").textContent !== "1") throw new Error("Orçamento não concluído");
  if(document.querySelector("#work-done-count").textContent!=="1"||!document.querySelector("#work-done-list").textContent.includes("Balança digital"))throw new Error("Painel lateral não moveu o orçamento para feitos");
  if (!document.querySelector(".card-total small").textContent.includes("3.300,00")) throw new Error("Melhor total incorreto");
  const times = [...document.querySelectorAll(".timeline-cell strong")].map((node) => node.textContent);
  if (times.includes("—")) throw new Error("Datas e horas incompletas");

  click("#export-excel"); await waitFor(() => downloads.length === 1); click("#export-word"); await waitFor(() => downloads.length === 2);
  const excel = Buffer.from(await downloads[0].arrayBuffer()); const word = Buffer.from(await downloads[1].arrayBuffer());
  fs.writeFileSync("/tmp/cota-certa-v2-test.xlsx", excel); fs.writeFileSync("/tmp/cota-certa-v2-test.doc", word);
  const zip = await JSZip.loadAsync(excel); const sheet = await zip.file("xl/worksheets/sheet1.xml").async("string");
  if (!sheet.includes("Disponibilidade no Brasil") || !sheet.includes("Destino da pesquisa") || !sheet.includes("Preço consultado em") || !word.toString("utf8").includes("PREÇO CONSULTADO EM:") || !word.toString("utf8").includes("FINALIZADO EM:") || !word.toString("utf8").includes("MÉDIA UNITÁRIA") || !word.toString("utf8").includes("DESTINO DA PESQUISA:") || !word.toString("utf8").includes("30120-082") || !document.querySelector(".delivery-context")?.textContent.includes("30120-082")) throw new Error("Exportação ou destino de pesquisa incompleto");
  if(sheet.includes("Evidência") || word.toString("utf8").includes(">evidência<"))throw new Error("Campo separado de evidência permaneceu na exportação");
  click("#open-import");
  await waitFor(()=>document.querySelectorAll("#data-health-list .data-health-item").length===3);
  if(!document.querySelector("#data-health-status").textContent.includes("3 situação") || !document.querySelector(".adopt-owner") || !document.querySelector(".restore-item"))throw new Error("Verificação da base não apresentou as recuperações disponíveis");
  const upload=new window.File(["Item;Categoria;Quantidade\nCaneta esferográfica azul;Papelaria;12\n"],"lista.csv",{type:"text/csv"});
  Object.defineProperty(document.querySelector("#import-files"),"files",{configurable:true,value:[upload]});
  document.querySelector("#import-files").dispatchEvent(new window.Event("change",{bubbles:true}));
  await waitFor(()=>document.querySelectorAll("#import-preview tbody tr").length===1);
  click("#confirm-import");
  await waitFor(()=>savedItems.some((item)=>item.name==="Caneta esferográfica azul"&&item.researchRuns?.length),7000);
  if(!savedItems.some((item)=>item.name==="Caneta esferográfica azul"&&item.references?.length===3))throw new Error("Importação não acionou a pesquisa automática");
  const imported=savedItems.find((item)=>item.name==="Caneta esferográfica azul");
  window.localStorage.setItem("cota-certa-research-queue-v1:user_biel123",JSON.stringify([imported.id]));
  firstPrice=0;click("#batch-toggle");
  await waitFor(()=>savedItems.find((item)=>item.id===imported.id)?.researchRuns?.length===2,7000);
  if(savedItems.find((item)=>item.id===imported.id).references[0].price!==0)throw new Error("Pesquisa de lista manteve preço anterior após nova requisição");
  firstPrice=1890;
  serviceMode = true; click("#open-budget-modal"); set("#budget-name", "Coordenador Cultural"); set("#budget-category", "Serviços"); set("#budget-specification", "Coordenação mensal de projetos culturais"); set("#budget-type", "Serviço"); set("#budget-unit", "mês"); submit("#budget-form");
  await waitFor(() => !document.querySelector("#research-body").hidden);
  if(document.querySelectorAll(".reference-card").length!==1||document.querySelectorAll(".research-status-item.missing").length!==2)throw new Error("Resultados parciais não foram separados das pendências");
  if (document.querySelector("[name='supplier-0']").value !== "Empresa Cultural" || document.querySelector("[name='price-0']").value || !document.querySelector("#research-result-label").textContent.includes("0 preço(s)")) throw new Error("Serviço sem preço foi apresentado como cotação pronta");
  if (!document.querySelector("#research-notice").classList.contains("warning") || document.querySelector("#average-value").textContent !== "—") throw new Error("Faltou explicar que a média do serviço está pendente");
  click("#export-excel");await waitFor(()=>downloads.length===3);
  const pendingXml=await (await JSZip.loadAsync(Buffer.from(await downloads[2].arrayBuffer()))).file("xl/worksheets/sheet1.xml").async("string");
  if(!pendingXml.includes("Coordenador Cultural") || !pendingXml.includes("PENDENTE"))throw new Error("Planilha apresentou preço zero como se fosse cotação real");
  if(document.querySelector("#delete-all-budgets").hidden)throw new Error("Administrador não recebeu a opção de excluir todos os orçamentos");
  click("#delete-all-budgets");
  if(!document.querySelector("#delete-all-dialog").open||!document.querySelector("#delete-all-count").textContent.includes("orçamentos serão excluídos"))throw new Error("Confirmação da exclusão em massa não foi exibida");
  set("#delete-all-confirmation","EXCLUIR TODOS");click("#confirm-delete-all");
  await waitFor(()=>savedItems.length===0&&document.querySelector("#metric-items").textContent==="0");
  if(!document.querySelector("#delete-all-budgets").hidden)throw new Error("Botão de exclusão em massa permaneceu ativo sem orçamentos");
  click("#user-button"); click("#logout-button"); if (document.querySelector("#auth-screen").hidden) throw new Error("Falha no logout");
  click("#auth-recover");
  if(document.querySelector("#auth-form-title").textContent!=="Recuperar acesso")throw new Error("Recuperação não apareceu");
  set("#auth-email","biel@example.com");set("#auth-password","nova-senha-123");set("#auth-confirm-password","nova-senha-123");
  submit("#auth-form");
  await waitFor(()=>!document.querySelector("#app-shell").hidden);
  click("#user-button");click("#logout-button");
  set("#auth-email","biel@example.com");set("#auth-password","senha123");submit("#auth-form");
  await waitFor(()=>!document.querySelector("#auth-alert").hidden);
  if(!document.querySelector("#app-shell").hidden)throw new Error("Senha anterior ainda entra");
  set("#auth-password","nova-senha-123");submit("#auth-form");
  await waitFor(()=>!document.querySelector("#app-shell").hidden);
  console.log(JSON.stringify({ ok:true, login:true, automaticResearch:3, activeCnpj:3, nationalStock:3, marketplaceBlocked:true, timestamps:times, excelBytes:excel.length, wordBytes:word.length }));
})().catch((error) => { console.error(error); process.exit(1); });
