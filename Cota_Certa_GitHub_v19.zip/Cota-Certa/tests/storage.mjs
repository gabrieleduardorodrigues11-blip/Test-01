import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { baseImport } from "../server/base-import.mjs";
import worker from "../dist/server/index.js";

const sqlite = new DatabaseSync(":memory:");
for (const file of readdirSync("drizzle").filter((name)=>name.endsWith(".sql")).sort())
  for (const statement of readFileSync(`drizzle/${file}`,"utf8").split("--> statement-breakpoint")) if(statement.trim())sqlite.exec(statement);
const DB = {
  prepare(sql) { return {bind(...args) { return {
    async all() { return {results:sqlite.prepare(sql).all(...args)}; },
    async first() { return sqlite.prepare(sql).get(...args); },
    async run() { return sqlite.prepare(sql).run(...args); }
  }; }}; },
  async batch(statements) {
    sqlite.exec("BEGIN");
    try { const results=[];for(const statement of statements)results.push(await statement.run());sqlite.exec("COMMIT");return results; }
    catch(error){sqlite.exec("ROLLBACK");throw error;}
  }
};
const blobs=new Map();
const BUCKET={async put(key,bytes){blobs.set(key,bytes);},async get(key){return blobs.has(key)?{body:blobs.get(key)}:null;},async delete(key){blobs.delete(key);}};
const env={DB,BUCKET};
const owner="site_user_123456",other="site_user_987654";
function request(path,method="GET",body,identity=owner,email=""){return new Request(`https://portal.example${path}`,{method,headers:{...(identity?{"oai-authenticated-user-id":identity}:{}),...(email?{"oai-authenticated-user-email":email}:{}),...(body instanceof FormData?{}:body?{"Content-Type":"application/json"}:{})},body:body instanceof FormData?body:body?JSON.stringify(body):undefined});}
const item={id:"item_12345678",name:"Caneta esferográfica azul",type:"Objeto",category:"Material escolar",quantity:12,unit:"un.",specification:"Ponta média, tinta azul",status:"draft",startedAt:new Date().toISOString(),updatedAt:new Date().toISOString(),references:[],researchRuns:[]};
assert.equal((await worker.fetch(request("/api/items","GET",null,null),env)).status,401);
assert.equal((await worker.fetch(request("/api/items","POST",{items:[item]}),env)).status,200);
assert.equal((await (await worker.fetch(request("/api/items"),env)).json()).items.length,1);
assert.equal((await (await worker.fetch(request("/api/items","GET",null,other),env)).json()).items.length,0);
const changed={...item,status:"review",references:[{supplier:"Fornecedor Azul",price:3.50,url:"https://loja.example/caneta"}]};
assert.equal((await worker.fetch(request("/api/items","POST",{items:[changed]}),env)).status,200);
assert.equal((await (await worker.fetch(request("/api/items"),env)).json()).items[0].references[0].price,3.5);
const form=new FormData();form.append("file",new File(["Item;Quantidade\nCaderno;3\nLápis;5"],"lista.csv",{type:"text/csv"}));form.append("items",JSON.stringify([{name:"Caderno",quantity:3,unit:"un.",category:"Escola",specification:"Caderno brochura"},{name:"Lápis",quantity:5,unit:"un.",category:"Escola",specification:"Lápis HB"}]));
const imported=await worker.fetch(request("/api/imports","POST",form),env);assert.equal(imported.status,201);
const {importId,imported:count}=await imported.json();assert.equal(count,2);
assert.equal((await (await worker.fetch(request("/api/items"),env)).json()).items.length,3);
assert.equal((await worker.fetch(request(`/api/imports/${importId}/download`),env)).status,200);
assert.equal((await worker.fetch(request(`/api/imports/${importId}/download`,"GET",null,other),env)).status,404);
assert.equal((await worker.fetch(request(`/api/items/${item.id}`,"DELETE"),env)).status,200);
assert.equal((await (await worker.fetch(request("/api/items"),env)).json()).items.length,2);
const adminEnv={...env,COTA_BASE_OWNER_EMAIL:"owner@example.com"};
const healthAfterDelete=await (await worker.fetch(request("/api/data-health","GET",null,owner,"owner@example.com"),adminEnv)).json();
assert.equal(healthAfterDelete.deletedItems.length,1);
assert.equal((await worker.fetch(request("/api/data-recovery/restore-item","POST",{itemId:item.id},owner,"owner@example.com"),adminEnv)).status,200);
assert.equal((await (await worker.fetch(request("/api/items"),env)).json()).items.length,3);
await worker.fetch(request(`/api/items/${item.id}`,"DELETE"),env);
const legacyItem={...item,id:"item_legacy_1234",name:"Item histórico"};
await worker.fetch(request("/api/items","POST",{items:[legacyItem]},other),env);
const legacyHealth=await (await worker.fetch(request("/api/data-health","GET",null,owner,"owner@example.com"),adminEnv)).json();
assert.equal(legacyHealth.legacyGroups[0].itemCount,1);
const adopted=await (await worker.fetch(request("/api/data-recovery/adopt-items","POST",{legacyOwnerId:other},owner,"owner@example.com"),adminEnv)).json();
assert.equal(adopted.recovered,1);
assert.equal((await (await worker.fetch(request("/api/items"),env)).json()).items.length,3);
const seededEnv={...env,COTA_BASE_OWNER_EMAIL:"owner@example.com"};
assert.equal((await (await worker.fetch(request("/api/items"),seededEnv)).json()).items.length,3);
const seeded=(await (await worker.fetch(request("/api/items","GET",null,owner,"owner@example.com"),seededEnv)).json()).items;
assert.equal(seeded.length,4);assert.equal(seeded.find((entry)=>entry.name==="RTX 5080")?.references.length,3);
assert.equal(seeded.find((entry)=>entry.name==="RTX 5080")?.references[0].cnpjStatus.active,false);
assert.equal((await (await worker.fetch(request("/api/items","GET",null,owner,"owner@example.com"),seededEnv)).json()).items.length,4);
assert.equal((await (await worker.fetch(request("/api/items","GET",null,other,"other@example.com"),seededEnv)).json()).items.length,0);
assert.equal((await worker.fetch(request(`/api/imports/${baseImport.id}/download`),seededEnv)).status,200);
assert.equal((await worker.fetch(request(`/api/imports/${baseImport.id}/download`,"GET",null,other),seededEnv)).status,404);
const foreignItem={...item,id:"item_foreign_1234",name:"Item de outra conta"};
await worker.fetch(request("/api/items","POST",{items:[foreignItem]},other,"other@example.com"),env);
assert.equal((await worker.fetch(request("/api/items/bulk-delete","POST",{confirmation:"EXCLUIR TODOS"},owner,"owner@example.com"),env)).status,403);
assert.equal((await worker.fetch(request("/api/items/bulk-delete","POST",{confirmation:"excluir todos"},owner,"owner@example.com"),adminEnv)).status,400);
const bulkResult=await (await worker.fetch(request("/api/items/bulk-delete","POST",{confirmation:"EXCLUIR TODOS"},owner,"owner@example.com"),adminEnv)).json();
assert.equal(bulkResult.deleted,4);assert.equal(bulkResult.recoverable,true);
assert.equal((await (await worker.fetch(request("/api/items","GET",null,owner,"owner@example.com"),env)).json()).items.length,0);
assert.equal((await (await worker.fetch(request("/api/items","GET",null,other,"other@example.com"),env)).json()).items.length,1);
const healthAfterBulk=await (await worker.fetch(request("/api/data-health","GET",null,owner,"owner@example.com"),adminEnv)).json();
assert.equal(healthAfterBulk.deletedItems.length,5);
assert.equal(healthAfterBulk.recentAudit[0].action,"soft_delete_all");
console.log("Base privada: isolamento, importação, exclusão recuperável, auditoria e recuperação de vínculo verificados");
