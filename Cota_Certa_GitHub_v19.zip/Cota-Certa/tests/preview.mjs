import assert from "node:assert/strict";
import worker from "../dist/server/index.js";

const files=new Map();
const env={
  BUCKET:{
    head:async (key)=>files.has(key)?{}:null,
    get:async (key)=>files.has(key)?{body:files.get(key)}:null,
    put:async (key,bytes)=>{files.set(key,new Uint8Array(bytes));}
  },
  COTA_BROWSER_ACCOUNT_ID:"test-account",
  COTA_BROWSER_TOKEN:"test-token"
};
let captures=0;
const originalFetch=globalThis.fetch;
globalThis.fetch=async (url)=>{
  assert.ok(String(url).startsWith("https://api.cloudflare.com/client/v4/accounts/test-account/browser-rendering/screenshot"));
  captures++;
  return new Response(new Uint8Array(130).fill(137),{headers:{"Content-Type":"image/png"}});
};
const headers={"oai-authenticated-user-id":"verified-user-123"};
try {
  const config=await worker.fetch(new Request("https://portal.example/api/preview/config",{headers}),env);
  assert.equal((await config.json()).available,true);
  const blocked=await worker.fetch(new Request("https://portal.example/api/preview",{method:"POST",headers:{...headers,"Content-Type":"application/json"},body:JSON.stringify({url:"https://enjoei.com.br/anuncio"})}),env);
  assert.equal(blocked.status,400);
  const unauthenticated=await worker.fetch(new Request("https://portal.example/api/preview/config"),env);
  assert.equal(unauthenticated.status,401);
  const input=new Request("https://portal.example/api/preview",{method:"POST",headers:{...headers,"Content-Type":"application/json"},body:JSON.stringify({url:"https://fornecedor.com.br/produto"})});
  const first=await worker.fetch(input,env);
  assert.equal(first.status,200);
  const {key}=await first.json();
  assert.match(key,/^[a-f0-9]{64}-\d{4}-\d{2}-\d{2}\.png$/);
  const image=await worker.fetch(new Request(`https://portal.example/api/preview?key=${key}`,{headers}),env);
  assert.equal(image.headers.get("Content-Type"),"image/png");
  assert.equal((await image.arrayBuffer()).byteLength,130);
  const repeated=await worker.fetch(new Request("https://portal.example/api/preview",{method:"POST",headers:{...headers,"Content-Type":"application/json"},body:JSON.stringify({url:"https://fornecedor.com.br/produto"})}),env);
  assert.equal((await repeated.json()).cached,true);
  assert.equal(captures,1);
  const other=await worker.fetch(new Request(`https://portal.example/api/preview?key=${key}`,{headers:{"oai-authenticated-user-id":"another-user-123"}}),env);
  assert.equal(other.status,404);
  console.log("Print: URL bloqueada, captura, cache e isolamento verificados.");
} finally { globalThis.fetch=originalFetch; }
