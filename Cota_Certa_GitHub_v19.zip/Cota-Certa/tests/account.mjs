import assert from "node:assert/strict";
import {handleAccount} from "../server/account.mjs";

// Match the PBKDF2 limit in the deployed Worker, which Node does not enforce.
const nativeCrypto=globalThis.crypto;
const nativeSubtle=nativeCrypto.subtle;
Object.defineProperty(globalThis,"crypto",{configurable:true,value:{
  getRandomValues:nativeCrypto.getRandomValues.bind(nativeCrypto),
  subtle:new Proxy(nativeSubtle,{get(target,property) {
    if(property==="deriveBits")return (options,...rest) => {
      if(options.iterations>100000)throw new Error("PBKDF2 excede o limite do Worker");
      return target.deriveBits(options,...rest);
    };
    const value=Reflect.get(target,property,target);
    return typeof value==="function"?value.bind(target):value;
  }})
}});

const rows=new Map();
const db={prepare(sql) {
  return {bind(...args) {
    return {
      async first() {
        assert.match(sql,/^SELECT/);
        return rows.get(args[0]) || null;
      },
      async run() {
        if(sql.startsWith("INSERT")) {
          const [id,email,name,password_salt,password_hash,created_at,updated_at]=args;
          rows.set(id,{id,email,name,password_salt,password_hash,created_at,updated_at});
        } else if(sql.startsWith("UPDATE accounts SET email=?,name=?")) {
          const [email,name,password_salt,password_hash,updated_at,id]=args;
          Object.assign(rows.get(id),{email,name,password_salt,password_hash,updated_at});
        } else if(sql.startsWith("UPDATE accounts SET email=?")) {
          const [email,updated_at,id]=args;
          Object.assign(rows.get(id),{email,updated_at});
        } else throw new Error("Unexpected query");
      }
    };
  }};
}};
const email="biel@example.com";
const id="trusted-account-123";
const env={DB:db,COTA_BASE_OWNER_EMAIL:email};
const request=(body,headers={})=>new Request("https://example.test/api/account",{
  method:body?"POST":"GET",
  headers:{"oai-authenticated-user-id":id,"oai-authenticated-user-email":email,...(body?{"Content-Type":"application/json"}:{}),...headers},
  ...(body?{body:JSON.stringify(body)}:{})
});
const call=async (body,headers)=>{const response=await handleAccount(request(body,headers),env);return {status:response.status,data:await response.json()};};

assert.equal((await call(undefined,{"oai-authenticated-user-id":""})).status,401);
assert.equal((await call()).data.registered,false);
assert.equal((await call({action:"signup",email:"other@example.com",name:"Biel",password:"nova-senha-123"})).status,403);
const signup=await call({action:"signup",email,name:"Biel",password:"senha-antiga-123"});
assert.equal(signup.status,200);
assert.equal(signup.data.profile.role,"Administrador");
assert.notEqual(rows.get(id).password_hash,"senha-antiga-123");
assert.equal((await call({action:"login",email,password:"senha-incorreta"})).status,401);
assert.equal((await call({action:"login",email,password:"senha-antiga-123"})).status,200);
const reset=await call({action:"recover",email,password:"senha-nova-456"});
assert.equal(reset.status,200);
assert.equal(reset.data.recovered,true);
assert.equal((await call({action:"login",email,password:"senha-antiga-123"})).status,401);
assert.equal((await call({action:"login",email,password:"senha-nova-456"})).status,200);
assert.equal((await call()).data.registered,true);
console.log("Conta: identidade, login e recuperação verificados.");
