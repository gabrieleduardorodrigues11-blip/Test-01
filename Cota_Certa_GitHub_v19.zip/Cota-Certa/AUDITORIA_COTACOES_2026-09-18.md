# Protocolo de auditoria — Cota Certa

Data: 18/09/2026. Escopo: pesquisa automática de preços, nova solicitação, pesquisa de lista, validações e exportação.

## Regra aplicada

Ao iniciar ou repetir uma pesquisa, o valor automático deve vir da página do fornecedor consultada naquele momento. O sistema guarda o horário da leitura e a fonte da oferta. Quando a página não publica um preço legível, o campo fica pendente. A média não recebe preço de trecho de buscador nem valor herdado da pesquisa anterior. Preço digitado por uma pessoa fica identificado como ajuste manual. Os registros anteriores continuam disponíveis como histórico; abrir um registro para revisão não dispara uma nova cotação.

## Falhas identificadas e protocolo de correção

| ID | Falha observada no código anterior | Efeito | Correção | Estado |
| --- | --- | --- | --- | --- |
| CC-01 | Preço de trecho de buscador podia entrar no orçamento se a página não publicasse o valor. | Média baseada em preço antigo ou sem vínculo claro com o item. | Aceitar preço automático apenas lido diretamente na página do fornecedor; trecho de buscador não preenche preço. | Corrigida; teste de API e cenários 1–2. |
| CC-02 | Nova pesquisa reutilizava a referência anterior quando a fonte deixava de responder ou publicar preço. | Parecia uma cotação vigente. | Limpar o valor antigo no novo pedido; preservar dados editados manualmente e exigir nova consulta de preço. | Corrigida; teste do fluxo individual e de lista. |
| CC-03 | Alteração manual em um campo bloqueava a atualização de todos os campos daquela referência. | Fornecedor editado mantinha preço desatualizado. | Conciliar referência manual pela mesma URL e CNPJ, manter identificação editada e substituir somente pelo preço recém-consultado; se a fonte não reaparecer, preço pendente. | Corrigida; teste de nova consulta. |
| CC-04 | Dois metadados de preço divergentes na mesma página podiam fazer o primeiro ser aceito. | Valor escolhido arbitrariamente. | Rejeitar o preço se os metadados legíveis discordarem. | Corrigida; 100 cenários simulados. |
| CC-05 | CNPJ encontrado apenas no resultado da busca podia ser associado a um fornecedor sem confirmação na página. | Identidade potencialmente incorreta. | Exigir CNPJ na página da oferta ou em página institucional do mesmo domínio, e consultar situação cadastral ativa. | Corrigida; cenários de CNPJ inválido e inativo. |
| CC-06 | Duas vitrines com o mesmo CNPJ podiam ocupar vagas de dois fornecedores. | Média com amostra menos independente do que aparenta. | Deduplicar por CNPJ na pesquisa integrada e na alternativa. | Corrigida; 100 cenários simulados. |
| CC-07 | Exportação registrava preço ausente como R$ 0,00. | Documento poderia parecer cotação real a preço zero. | Exibir PENDENTE, acrescentar hora de consulta e origem do preço no Excel e no Word. | Corrigida; teste de exportação. |
| CC-08 | Página da oferta podia ser lida por cache do cliente. | Risco de obter conteúdo antigo. | Solicitar a página com `cache: no-store` e `Cache-Control: no-cache`; manter horário da leitura. | Corrigida na requisição; o servidor do fornecedor ainda pode responder com conteúdo próprio desatualizado. |

## Testes executados

- **1.000 cenários automatizados simulados**, em 10 grupos de 100, com valores unitários variados: metadados de produto válidos, preço divergente entre buscador e página, preço ausente, metadados contraditórios, validade expirada, marketplace recusado, CNPJ inválido, CNPJ inativo, vitrines duplicadas e página indisponível. Todos passaram.
- Teste do fluxo completo: cadastro e login; pesquisa individual; mudança de preço; nova tentativa sem preço; busca sem ofertas; preservação da edição do fornecedor; três fornecedores; validação de CNPJ e estoque; bloqueio de marketplaces; horário; geração Word e Excel; importação e nova pesquisa de lista; serviço sem preço publicado; redefinição de senha. Passou com respostas externas simuladas.
- Testes separados de importação, banco privado, isolamento por usuário, endpoint de pesquisa, captura de prints e autenticação. Passaram.

## Limites ainda existentes

| ID | Condição | Tratamento atual |
| --- | --- | --- |
| CC-R01 | Loja que apresenta valor somente após executar JavaScript, entrar na conta, selecionar variação ou informar CEP pode não revelar preço no HTML lido. | Deixa preço pendente; exige conferência direta ou integração autorizada com a loja. |
| CC-R02 | Preço consultado na página pode mudar após a leitura; frete, impostos, descontos e entrega para Belo Horizonte/CEP 30120-082 não são calculados automaticamente. | A cotação registra data e hora; confirmação comercial e prova de disponibilidade continuam necessárias. |
| CC-R03 | Buscadores, consulta cadastral ou páginas de fornecedores podem ficar indisponíveis, bloquear robôs ou entregar dados insuficientes. | Não inventar preço ou CNPJ e informar pendência para revisão. |
| CC-R04 | Cotações antigas não ganham verificação de preço retroativa. | Fazer nova pesquisa para registrar um preço consultado naquele momento; cotações antigas seguem como histórico. |

**Alcance da validação:** os 1.000 cenários usaram respostas controladas para garantir repetibilidade. Eles não equivalem a 1.000 acessos independentes a sites reais nem provam valores vigentes de fornecedores externos. As integrações ao vivo dependem de acesso dos fornecedores e da fonte de busca quando uma cotação real for solicitada.
