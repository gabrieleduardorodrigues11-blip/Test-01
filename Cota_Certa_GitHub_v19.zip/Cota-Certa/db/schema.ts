import { integer, index, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const items = sqliteTable("items", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  category: text("category").notNull(),
  quantity: integer("quantity").notNull(),
  unit: text("unit").notNull(),
  specification: text("specification").notNull(),
  status: text("status").notNull(),
  startedAt: text("started_at").notNull(),
  finishedAt: text("finished_at"),
  createdBy: text("created_by"),
  createdByUserId: text("created_by_user_id"),
  updatedAt: text("updated_at").notNull(),
  referencesJson: text("references_json").notNull().default("[]"),
  researchRunsJson: text("research_runs_json").notNull().default("[]"),
  comparable: integer("comparable", { mode: "boolean" }).notNull().default(false),
  importId: text("import_id"),
  deletedAt: text("deleted_at")
}, (table) => [
  index("items_owner_updated_idx").on(table.ownerId, table.updatedAt),
  index("items_owner_category_idx").on(table.ownerId, table.category),
  index("items_owner_import_idx").on(table.ownerId, table.importId)
]);

export const imports = sqliteTable("imports", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  filename: text("filename").notNull(),
  mimeType: text("mime_type").notNull(),
  byteLength: integer("byte_length").notNull(),
  objectKey: text("object_key").notNull(),
  itemCount: integer("item_count").notNull(),
  createdAt: text("created_at").notNull()
}, (table) => [index("imports_owner_created_idx").on(table.ownerId, table.createdAt)]);

export const accounts = sqliteTable("accounts", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  passwordSalt: text("password_salt").notNull(),
  passwordHash: text("password_hash").notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
});

export const auditEvents = sqliteTable("audit_events", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id"),
  detailsJson: text("details_json").notNull().default("{}"),
  createdAt: text("created_at").notNull()
}, (table) => [index("audit_events_owner_created_idx").on(table.ownerId, table.createdAt)]);
