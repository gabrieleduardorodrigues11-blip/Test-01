CREATE TABLE `imports` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`filename` text NOT NULL,
	`mime_type` text NOT NULL,
	`byte_length` integer NOT NULL,
	`object_key` text NOT NULL,
	`item_count` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `imports_owner_created_idx` ON `imports` (`owner_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `items` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`name` text NOT NULL,
	`type` text NOT NULL,
	`category` text NOT NULL,
	`quantity` integer NOT NULL,
	`unit` text NOT NULL,
	`specification` text NOT NULL,
	`status` text NOT NULL,
	`started_at` text NOT NULL,
	`finished_at` text,
	`created_by` text,
	`created_by_user_id` text,
	`updated_at` text NOT NULL,
	`references_json` text DEFAULT '[]' NOT NULL,
	`research_runs_json` text DEFAULT '[]' NOT NULL,
	`comparable` integer DEFAULT false NOT NULL,
	`import_id` text
);
--> statement-breakpoint
CREATE INDEX `items_owner_updated_idx` ON `items` (`owner_id`,`updated_at`);--> statement-breakpoint
CREATE INDEX `items_owner_category_idx` ON `items` (`owner_id`,`category`);