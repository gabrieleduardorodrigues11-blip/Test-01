CREATE TABLE `audit_events` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`action` text NOT NULL,
	`entity_type` text NOT NULL,
	`entity_id` text,
	`details_json` text DEFAULT '{}' NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `audit_events_owner_created_idx` ON `audit_events` (`owner_id`,`created_at`);--> statement-breakpoint
ALTER TABLE `items` ADD `deleted_at` text;--> statement-breakpoint
CREATE INDEX `items_owner_import_idx` ON `items` (`owner_id`,`import_id`);